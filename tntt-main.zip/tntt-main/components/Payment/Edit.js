import { fetchPutJSON, timeToString } from "@lib/healper";
import { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { CgSpinner } from "react-icons/cg";
import { GlobalContext } from "@lib/globalContext";

const EditPayment = ({ data }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [date, setDate] = useState(data.date || "");
  const [method, setMethod] = useState(data.method || "");
  const [checkId, setCheckId] = useState(data.checkId || "");
  const [amount, setAmount] = useState(data.amount || "");
  const [receivedBy, setReceivedBy] = useState(data.receivedBy || "");
  const { doRefrash, setDoRefrash } = useContext(GlobalContext);

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPutJSON("/api/payments", {
      id: data._id,
      ...(date &&
        date !== data.date && {
          date: date,
        }),
      ...(method &&
        method !== data.method && {
          method: method,
        }),
      ...(checkId !== data.checkId && {
        checkId: checkId,
      }),
      ...(amount &&
        amount !== data.amount && {
          amount: amount,
        }),
      ...(receivedBy &&
        receivedBy !== data.receivedBy && {
          receivedBy: receivedBy,
        }),
    });
    if (response.statusCode === 200) {
      toast.success(response.message, { duration: 4000 });
      setIsLoading(false);
      setDoRefrash(!doRefrash);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  useEffect(() => {
    const unsubs = async () => {
      if (method == "cash") {
        setCheckId("");
      }
    };
    return unsubs();
  }, [method]);

  return (
    <div className="w-full py-4 px-4 sticky left-0 bg-pink-50 bg-opacity-70 border-pink-400 border-2 border-t-1">
      <form onSubmit={onSubmit}>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Date</p>
            <input
              onChange={(event) => {
                setDate(event.target.value);
              }}
              value={timeToString(date, "YYYY-MM-DD")}
              required
              type="date"
              name="date"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Payment Method
            </p>
            <select
              className="block invalid:text-gray-500 rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              required
              name="method"
              onChange={(event) => {
                setMethod(event.target.value);
              }}
            >
              <option disabled value="" selected={!method}>
                ...
              </option>
              <option selected={method == "cash"} value="cash">
                Cash
              </option>
              <option selected={method == "check"} value="check">
                Check
              </option>
            </select>
          </div>
          {method == "check" && (
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Check ID</p>
              <input
                onChange={(event) => {
                  setCheckId(event.target.value);
                }}
                value={checkId}
                required
                type="text"
                name="check-id"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
          )}
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Amount</p>
            <input
              onChange={(event) => {
                setAmount(event.target.value);
              }}
              value={amount}
              required
              type="number"
              name="amount"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Received By</p>
            <input
              onChange={(event) => {
                setReceivedBy(event.target.value);
              }}
              value={receivedBy}
              required
              type="text"
              name="receved-by"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
        </div>
        <button
          disabled={isLoading}
          type="submit"
          className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
        >
          {isLoading ? (
            <span className="inline-flex text-2xl animate-spin text-white">
              <CgSpinner />
            </span>
          ) : (
            "Update"
          )}
        </button>
        {errorMessage ? (
          <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
            {errorMessage}
          </div>
        ) : null}
      </form>
    </div>
  );
};

export default EditPayment;
