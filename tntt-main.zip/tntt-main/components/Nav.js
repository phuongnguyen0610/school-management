import Link from "next/link";
import { useState, useEffect } from "react";
import { FiHome } from "react-icons/fi";
import { RiLogoutBoxRLine } from "react-icons/ri";
import { useSession, signOut } from "next-auth/client";

const Nav = () => {
  const [authLink, setAuthLink] = useState({ title: null, url: "/" });
  const [profileLink, setProfileLink] = useState({
    title: "Need Help?",
    url: "/help",
  });
  const [session, loading] = useSession();
  const user = !!session?.user;
  useEffect(() => {
    if (!loading) {
      if (!user) {
        setAuthLink({ title: "Register / Login", url: "/login" });
      } else {
        setAuthLink({
          title: `Hi, ${session?.user?.name?.lastName}`,
          url: "/logout",
        });
        if (session?.user?.role === "super") {
          setProfileLink({ title: "Admin Area", url: "/admin" });
        } else if (session?.user?.role === "admin") {
          setProfileLink({ title: "Admin Area", url: "/admin/family" });
        } else {
          setProfileLink({ title: "Parents Area", url: "/parents" });
        }
      }
    }
  }, [loading, user]);
  return (
    <header className="fixed z-40 left-0 top-0 w-full h-[70px] bg-white dark:bg-black bg-opacity-70 dark:bg-opacity-70 backdrop-filter backdrop-blur-lg backdrop-saturate-150 border-b border-gray-200 dark:border-gray-800">
      <div className="w-full pl-16 h-full flex justify-between items-center">
        <div className="flex justify-center items-center h-full">
          <Link href="/">
            <a className="uppercase border-r h-full pr-8 flex text-sm font-semibold items-center justify-center duration-300 hover:text-primary">
              <FiHome className="mr-1" />
              <span className=" inline-block mt-0.5">Home</span>
            </a>
          </Link>
          {user && (
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="px-8 text-sm text-pink-600 font-semibold uppercase flex justify-center items-center duration-300 hover:text-pink-400"
            >
              Logout <RiLogoutBoxRLine className="ml-1" />
            </button>
          )}
        </div>

        <div className="font-medium flex items-center justify-center h-full">
          {user ? (
            <a className="uppercase hidden sm:block text-sm font-semibold px-8">
              {authLink.title}
            </a>
          ) : (
            <Link href={authLink.url}>
              <a className="uppercase hidden sm:block text-sm font-semibold px-8 duration-300 hover:text-gray-500">
                {authLink.title}
              </a>
            </Link>
          )}
          <Link href={profileLink.url}>
            <a className="uppercase text-sm font-semibold text-white bg-primary px-12 h-full flex justify-center items-center duration-300 hover:bg-pink-300">
              {profileLink.title}
            </a>
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Nav;
