import Link from "next/link";
import { useSession } from "next-auth/client";
import { useEffect, useState } from "react";

const Hero = () => {
  const [getStartedLink, setGetStartedLink] = useState("/");
  const [session, loading] = useSession();
  const user = !!session?.user;

  useEffect(() => {
    if (!loading) {
      if (!user) {
        setGetStartedLink("/parents");
      } else {
        if (
          session?.user?.role === "super" ||
          session?.user?.role === "admin"
        ) {
          setGetStartedLink("/admin");
        } else {
          setGetStartedLink("/parents");
        }
      }
    }
  }, [loading, user]);

  return (
    <div className="w-full h-screen fixed inset-0 flex flex-col justify-center items-center">
      <img
        className="mb-8 max-w-xs sm:max-w-md"
        src="/img/svg/back-to-school.svg"
      />
      <div className="text-center">
        <h1 className="sm:text-5xl text-4xl font-bold text-gray-700 font-serif">
          Hi, there <span className="animate-wave inline-block">👋</span>
        </h1>
        <p className="font-medium font-serif text-xl">Welcome back to school</p>
        <Link href={getStartedLink}>
          <a className="mt-4 block bg-primary w-max mx-auto px-8 py-2 font-semibold text-white rounded-md duration-300 hover:bg-pink-300">
            Get Started
          </a>
        </Link>
      </div>
    </div>
  );
};

export default Hero;
