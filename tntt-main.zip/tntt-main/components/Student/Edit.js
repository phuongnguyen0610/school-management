import { fetchPutJSON, fetchGetJSON, timeToString, getAge } from "@lib/healper";
import { useContext, useEffect, useState } from "react";
import toast from "react-hot-toast";
import { CgSpinner } from "react-icons/cg";
import { GlobalContext } from "@lib/globalContext";
import Toggle from "@components/Toggle";

const EditStudent = ({ data }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [familyId, setFamilyId] = useState(data.familyId || "");
  const [firstName, setFirstName] = useState(data.firstName || "");
  const [lastName, setLastName] = useState(data.lastName || "");
  const [DOB, setDOB] = useState(data.DOB || "");
  const [saint, setSaint] = useState(data.saint || "");
  const [nganh, setNganh] = useState(data.nganh || "");
  const [cap, setCap] = useState(data.cap || "");
  const [year, setYear] = useState(data.year || "");
  const [age, setAge] = useState(data.age || "");
  const [gender, setGender] = useState(data.gender || "");
  const [medical, setMedical] = useState(data.medical || "");
  const [schoolName, setSchoolName] = useState(data.schoolName || "");
  const [enrolled, setEnrolled] = useState(data.enrolled || false);
  const [notes, setNotes] = useState(data.notes || "");
  const [families, setFamilies] = useState([]);
  const [schools, setSchools] = useState([]);
  const { doRefrash, setDoRefrash } = useContext(GlobalContext);

  const nganhList = ["Au Nhi", "Thieu Nhi", "Nghia Si", "Hiep Si"];

  const onSubmit = async (event) => {
    event.preventDefault();
    if (!familyId || !schoolName) {
      toast.error("Please provide all the information!");
      return;
    }
    if (age < 7 || age > 18) {
      return toast.error("Age should be between 7-18!");
    }
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPutJSON("/api/students", {
      id: data._id,
      ...(familyId &&
        familyId !== data.familyId && {
          familyId: familyId,
        }),
      ...(firstName &&
        firstName !== data.firstName && {
          firstName: firstName,
        }),
      ...(lastName !== data.lastName && {
        lastName: lastName,
      }),
      ...(DOB &&
        DOB !== data.DOB && {
          DOB: DOB,
        }),
      ...(saint &&
        saint !== data.saint && {
          saint: saint,
        }),
      ...(nganh &&
        nganh !== data.nganh && {
          nganh: nganh,
        }),
      ...(cap &&
        cap !== data.cap && {
          cap: cap,
        }),
      ...(year &&
        year !== data.year && {
          year: year,
        }),
      ...(age &&
        age !== data.age && {
          age: age,
        }),
      ...(gender &&
        gender !== data.gender && {
          gender: gender,
        }),
      ...(medical !== data.medical && {
        medical: medical,
      }),
      ...(schoolName &&
        schoolName !== data.schoolName && {
          schoolName: schoolName,
        }),
      ...(enrolled !== data.enrolled && {
        enrolled: enrolled,
      }),
      ...(notes &&
        notes !== data.notes && {
          notes: notes,
        }),
    });
    if (response.statusCode === 200) {
      toast.success(response.message, { duration: 4000 });
      setIsLoading(false);
      setDoRefrash(!doRefrash);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  const toggleEnrolled = () => {
    setEnrolled(!enrolled);
  };

  const getNganh = (age) => {
    if (age < 7 || age > 18) {
      return "";
    }
    if (age >= 7 && age <= 9) {
      return nganhList[0];
    } else if (age >= 10 && age <= 12) {
      return nganhList[1];
    } else if (age >= 13 && age <= 15) {
      return nganhList[2];
    } else if (age >= 16 && age <= 18) {
      return nganhList[3];
    } else {
      return "";
    }
  };

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/family");
      if (response.statusCode === 200) {
        setFamilies(response?.families);
      }
      const response_schools = await fetchGetJSON("/api/schools");
      if (response_schools.statusCode === 200) {
        setSchools(response_schools?.schools);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, []);

  useEffect(() => {
    const unsubs = async () => {
      if (DOB) {
        const currentAge = getAge(DOB);
        if (currentAge > 0) {
          setAge(currentAge);
        } else {
          setAge(0);
        }
      }
    };
    return unsubs();
  }, [DOB]);

  useEffect(() => {
    const unsubs = async () => {
      if (age) {
        const currentCap = age % 3;
        if (currentCap === 0) {
          setCap(3);
        } else {
          setCap(currentCap);
        }
      } else {
        setCap("");
      }

      setNganh(getNganh(age));
    };
    return unsubs();
  }, [age]);

  return (
    <div className="w-full py-4 px-4 sticky left-0 bg-pink-50 bg-opacity-70 border-pink-400 border-2 border-t-1">
      <form onSubmit={onSubmit}>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">First Name</p>
            <input
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
              value={firstName}
              required
              type="text"
              name="fname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Last Name</p>
            <input
              onChange={(event) => {
                setLastName(event.target.value);
              }}
              value={lastName}
              required
              type="text"
              name="lname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Date of Birth</p>
            <input
              onChange={(event) => {
                setDOB(event.target.value);
              }}
              value={timeToString(DOB, "YYYY-MM-DD")}
              required
              type="date"
              name="dob"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Saint</p>
            <input
              onChange={(event) => {
                setSaint(event.target.value);
              }}
              value={saint}
              required
              type="text"
              name="saint"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Age</p>
            <input
              onChange={(event) => {
                setAge(event.target.value);
              }}
              value={age}
              readOnly
              required
              type="number"
              name="age"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Gender</p>
            <select
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              required
              name="gender"
              onChange={(event) => {
                setGender(event.target.value);
              }}
            >
              <option disabled value="" selected={!gender}>
                ...
              </option>
              <option selected={gender == "male"} value="male">
                Male
              </option>
              <option selected={gender == "female"} value="female">
                Female
              </option>
              <option selected={gender == "unknown"} value="unknown">
                Prefer not to say
              </option>
            </select>
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600 line-clamp-1">
              Allergies/Medical Problems/Disabilities
            </p>
            <input
              onChange={(event) => {
                setMedical(event.target.value);
              }}
              value={medical}
              type="text"
              name="medical"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Family ID </p>
            <select
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              required
              name="family"
              onChange={(event) => {
                setFamilyId(event.target.value);
              }}
              >
                {families.filter(fam => fam.familyId == data.familyId).map((family) => (
                  <option
                    value={family.familyId}
                    selected={familyId == family.familyId}
                  >{`ID : ${family.familyId} - Father :  ${family.fatherFirstName} ${family.fatherLastName}`}</option>
                ))}
              </select>
          </div>
          <div className="flex flex-1 flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Church</p>
            <select
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              required
              name="schools"
              onChange={(event) => {
                setSchoolName(event.target.value);
              }}
            >
              <option disabled value="" selected={!schoolName}>
                ...
              </option>
              {schools.map((school) => (
                <option
                  value={school.name}
                  selected={schoolName == school.name}
                >{`${school.schoolId} - ${school.name}`}</option>
              ))}
            </select>
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600 line-clamp-1">
              Nganh
            </p>
            <input
              onChange={(event) => {
                setNganh(event.target.value);
              }}
              readOnly
              value={nganh}
              type="text"
              name="nganh"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600 line-clamp-1">
              Cap
            </p>
            <input
              onChange={(event) => {
                setCap(event.target.value);
              }}
              readOnly
              value={cap}
              type="text"
              name="cap"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex space-x-2">
            <div className="flex flex-col space-y-1 flex-1">
              <p className="font-semibold text-sm text-gray-600 line-clamp-1">
                Year
              </p>
              <input
                onChange={(event) => {
                  setYear(event.target.value);
                }}
                required
                value={year}
                type="text"
                name="year"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600 mb-1">
                Enrolled
              </p>
              <Toggle enabled={enrolled} onChange={toggleEnrolled} />
            </div>
          </div>
          <div className="flex flex-col space-y-1 md:col-span-2 lg:col-span-3">
            <p className="font-semibold text-sm text-gray-600">Notes</p>
            <textarea
              onChange={(event) => {
                setNotes(event.target.value);
              }}
              value={notes}
              type="text"
              name="notes"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
        </div>
        <button
          disabled={isLoading}
          type="submit"
          className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
        >
          {isLoading ? (
            <span className="inline-flex text-2xl animate-spin text-white">
              <CgSpinner />
            </span>
          ) : (
            "Update"
          )}
        </button>
        {errorMessage ? (
          <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
            {errorMessage}
          </div>
        ) : null}
      </form>
    </div>
  );
};

export default EditStudent;
