import { fetchPutJSON } from "@lib/healper";
import { useContext, useState } from "react";
import toast from "react-hot-toast";
import { CgSpinner } from "react-icons/cg";
import { GlobalContext } from "@lib/globalContext";

const EditSchool = ({ data }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [name, setName] = useState(data.name || "");
  const [location, setLocation] = useState(data.location || "");
  const { doRefrash, setDoRefrash } = useContext(GlobalContext);

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPutJSON("/api/schools", {
      id: data._id,
      ...(name && name !== data.name && { name: name }),
      ...(location && location !== data.location && { location: location }),
    });
    if (response.statusCode === 200) {
      toast.success(response.message, { duration: 4000 });
      setIsLoading(false);
      setDoRefrash(!doRefrash);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  return (
    <div className="w-full relative py-4 px-4 bg-pink-50 bg-opacity-70 border-pink-400 border-2 border-t-1">
      <form onSubmit={onSubmit}>
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Name of Church
            </p>
            <input
              onChange={(event) => {
                setName(event.target.value);
              }}
              value={name}
              required
              type="text"
              name="school-name"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Location</p>
            <input
              onChange={(event) => {
                setLocation(event.target.value);
              }}
              value={location}
              required
              type="text"
              name="location"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
        </div>
        <button
          disabled={isLoading}
          type="submit"
          className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
        >
          {isLoading ? (
            <span className="inline-flex text-2xl animate-spin text-white">
              <CgSpinner />
            </span>
          ) : (
            "Update"
          )}
        </button>
        {errorMessage ? (
          <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
            {errorMessage}
          </div>
        ) : null}
      </form>
    </div>
  );
};

export default EditSchool;
