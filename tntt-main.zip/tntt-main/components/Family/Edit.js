import { fetchPutJSON } from "@lib/healper";
import { useContext, useState } from "react";
import toast from "react-hot-toast";
import { CgSpinner } from "react-icons/cg";
import { GlobalContext } from "@lib/globalContext";

const EditFamily = ({ data }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [fatherFirstName, setFatherFirstName] = useState(
    data.fatherFirstName || data.fatherFirstName || ""
  );
  const [fatherLastName, setFatherLastName] = useState(
    data.fatherLastName || ""
  );
  const [fatherPhone, setFatherPhone] = useState(data.fatherPhone || "");
  const [motherFirstName, setMotherFirstName] = useState(
    data.motherFirstName || ""
  );
  const [motherLastName, setMotherLastName] = useState(
    data.motherLastName || ""
  );
  const [motherPhone, setMotherPhone] = useState(data.motherPhone || "");
  const [city, setCity] = useState(data.city || "");
  const [state, setState] = useState(data.state || "");
  const [zip, setZip] = useState(data.zip || "");
  const [address, setAddress] = useState(data.address || "");
  const { doRefrash, setDoRefrash } = useContext(GlobalContext);

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPutJSON("/api/family", {
      id: data._id,
      ...(fatherFirstName &&
        fatherFirstName !== data.fatherFirstName && {
          fatherFirstName: fatherFirstName,
        }),
      ...(fatherLastName &&
        fatherLastName !== data.fatherLastName && {
          fatherLastName: fatherLastName,
        }),
      ...(fatherPhone &&
        fatherPhone !== data.fatherPhone && { fatherPhone: fatherPhone }),
      ...(motherFirstName &&
        motherFirstName !== data.motherFirstName && {
          motherFirstName: motherFirstName,
        }),
      ...(motherLastName &&
        motherLastName !== data.motherLastName && {
          motherLastName: motherLastName,
        }),
      ...(motherPhone &&
        motherPhone !== data.motherPhone && { motherPhone: motherPhone }),
      ...(city && city !== data.city && { city: city }),
      ...(state && state !== data.state && { state: state }),
      ...(zip && zip !== data.zip && { zip: zip }),
      ...(address && address !== data.address && { address: address }),
    });
    if (response.statusCode === 200) {
      toast.success(response.message, { duration: 4000 });
      setIsLoading(false);
      setDoRefrash(!doRefrash);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  return (
    <div className="w-full max-w-[85vw] md:max-w-[90vw] lg:max-w-[75vw] xl:max-w-[1170px] py-4 px-4 sticky left-0 bg-pink-50 bg-opacity-70 border-pink-400 border-2 border-t-1">
      <form onSubmit={onSubmit}>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Father's First Name
            </p>
            <input
              onChange={(event) => {
                setFatherFirstName(event.target.value);
              }}
              value={fatherFirstName}
              required
              type="text"
              name="fname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Father's Last Name
            </p>
            <input
              onChange={(event) => {
                setFatherLastName(event.target.value);
              }}
              value={fatherLastName}
              required
              type="text"
              name="lname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Father's Phone
            </p>
            <input
              onChange={(event) => {
                setFatherPhone(event.target.value);
              }}
              value={fatherPhone}
              required
              type="tel"
              name="phone"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Mother's First Name
            </p>
            <input
              onChange={(event) => {
                setMotherFirstName(event.target.value);
              }}
              value={motherFirstName}
              required
              type="text"
              name="fname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Mother's Last Name
            </p>
            <input
              onChange={(event) => {
                setMotherLastName(event.target.value);
              }}
              value={motherLastName}
              required
              type="text"
              name="lname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">
              Mother's Phone
            </p>
            <input
              onChange={(event) => {
                setMotherPhone(event.target.value);
              }}
              value={motherPhone}
              required
              type="tel"
              name="phone"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">City</p>
            <input
              onChange={(event) => {
                setCity(event.target.value);
              }}
              value={city}
              required
              type="text"
              name="city"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">State</p>
            <input
              onChange={(event) => {
                setState(event.target.value);
              }}
              value={state}
              required
              type="text"
              name="state"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Zip</p>
            <input
              onChange={(event) => {
                setZip(event.target.value);
              }}
              value={zip}
              required
              type="text"
              name="zip"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Address</p>
            <input
              onChange={(event) => {
                setAddress(event.target.value);
              }}
              value={address}
              required
              type="text"
              name="address"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
        </div>
        <button
          disabled={isLoading}
          type="submit"
          className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
        >
          {isLoading ? (
            <span className="inline-flex text-2xl animate-spin text-white">
              <CgSpinner />
            </span>
          ) : (
            "Update"
          )}
        </button>
        <a href={'/admin/family/' + data.familyId} target="_blank" >
          <button
            disabled={isLoading}
            type="button"
            className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-green-500 hover:bg-green-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
          >View Children
          </button>
        </a>
        {errorMessage ? (
          <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
            {errorMessage}
          </div>
        ) : null}
      </form>
    </div>
  );
};

export default EditFamily;
