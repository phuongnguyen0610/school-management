import {
  fetchPutJSON,
  customTableStyles,
  fetchDeleteJSON,
  fetchGetJSON,
  timeToString,
} from "@lib/healper";
import { useState, useEffect, useMemo, useContext } from "react";
import toast from "react-hot-toast";
import DataTable from "react-data-table-component";
import { CgSpinner } from "react-icons/cg";
import { BsEyeFill } from "react-icons/bs";
import { AiOutlineUserAdd } from "react-icons/ai";
import { GlobalContext } from "@lib/globalContext";
import Link from "next/link";

const ViewChildren = ({ data }) => {

  const [children, setChildren] = useState([]);
  const { doRefrash } = useContext(GlobalContext);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON('/api/family/' + data.familyId);
      if (response.statusCode === 200) {
        setChildren(response?.students);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  const columns = useMemo(
    () => [
      {
        cell: (row) => viewButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
      {
        name: "Saint",
        selector: (row) => `${row.saint}`,
        sortable: false,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Name",
        selector: (row) => `${row.firstName}`,
        sortable: false,
        format: (row, index) => {
          return `${row.firstName} ${row.lastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Date of Birth",
        selector: (row) => `${row.DOB}`,
        sortable: true,
        format: (row, index) => {
          return timeToString(row.DOB, "MMM DD, YYYY");
        },
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Age",
        selector: (row) => `${row.age}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Gender",
        selector: (row) => `${row.gender}`,
        sortable: false,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Created At",
        selector: (row) => `${row.createdAt}`,
        sortable: false,
        format: (row, index) => {
          return timeToString(row.createdAt, "MMM DD, YYYY");
        },
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      // {
      //   cell: (row) => deleteButton(row),
      //   allowOverflow: true,
      //   button: true,
      //   width: "56px",
      // },
    ],
    []
  );
  // const deleteButton = (familyData) => {
  //   return (
  //     <button
  //       disabled={isBusy}
  //       onClick={() => deleteFamily(familyData)}
  //       title="Delete this family"
  //       className="text-pink-600 text-lg"
  //     >
  //       <FiTrash2 />
  //     </button>
  //   );
  // };
  const viewButton = (childData) => {
    return (
      <Link href={`/admin/children/${childData.studentId}`}>
        <a className="text-green-600 text-lg">
          <BsEyeFill />
        </a>
      </Link>
    );
  };

  return (
    <div className="w-full relative">
      <DataTable
      // defaultSortFieldId="createdAt"
      columns={columns}
      data={children}
      customStyles={customTableStyles}
      title="All Children"
      // expandableRows
      // expandableRowsComponent={EditFamily}
      defaultSortDsc={true}
      highlightOnHover
      noHeader
    />
    <a href={'/admin/children/add/'+ data.familyId}>
      <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
        <span className="hidden md:block">Add New Child</span>{" "}
        <AiOutlineUserAdd className="block md:ml-2 text-xl" />
      </button>
    </a>
  </div>
  );
};

export default ViewChildren;
