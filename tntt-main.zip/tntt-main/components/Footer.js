import { FaFacebook, FaTwitter, FaInstagram } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="fixed w-full h-16 flex justify-between items-center px-16 left-0 bottom-0">
      <div className="font-bold text-sm text-pink-900">
        © Phuong Nguyen 2021
      </div>
      {/* <div className="flex items-center justify-center space-x-4">
        <a href="#" className="text-pink-900">
          <FaTwitter />
        </a>
        <a href="#" className="text-pink-900">
          <FaFacebook />
        </a>
        <a href="#" className="text-pink-900">
          <FaInstagram />
        </a>
      </div> */}
    </footer>
  );
};

export default Footer;
