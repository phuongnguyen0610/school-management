import { fetchPutJSON } from "@lib/healper";
import { useContext, useState } from "react";
import toast from "react-hot-toast";
import { CgSpinner } from "react-icons/cg";
import { GlobalContext } from "@lib/globalContext";

const EditUser = ({ data }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState(data.email || "");
  const [firstName, setFirstName] = useState(data.firstName || "");
  const [lastName, setLastName] = useState(data.lastName || "");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState(data.role || "");
  const { doRefrash, setDoRefrash } = useContext(GlobalContext);

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPutJSON("/api/users", {
      id: data._id,
      ...(firstName &&
        firstName !== data.firstName && { firstName: firstName }),
      ...(lastName && lastName !== data.lastName && { lastName: lastName }),
      ...(email && email !== data.email && { email: email }),
      ...(role && role !== data.role && { role: role }),
      ...(password && { password: password }),
    });
    console.log(response);
    if (response.statusCode === 200) {
      toast.success(response.message, { duration: 4000 });
      setIsLoading(false);
      setDoRefrash(!doRefrash);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  return (
    <div className="w-full relative py-4 px-4 bg-pink-50 bg-opacity-70 border-pink-400 border-2 border-t-1">
      <form onSubmit={onSubmit}>
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">First Name</p>
            <input
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
              value={firstName}
              required
              type="text"
              name="fname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Last Name</p>
            <input
              onChange={(event) => {
                setLastName(event.target.value);
              }}
              value={lastName}
              required
              type="text"
              name="lname"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Email Address</p>

            <input
              onChange={(event) => {
                setEmail(event.target.value);
              }}
              value={email}
              name="email"
              required
              type="email"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>

          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Role</p>
            <select
              className="block invalid:text-gray-500 rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              required
              name="role"
              onChange={(event) => {
                setRole(event.target.value);
              }}
            >
              <option disabled value="" selected={role == ""}>
                ...
              </option>
              <option value="admin" selected={role == "admin"}>
                Admin
              </option>
              <option value="parent" selected={role == "parent"}>
                Parent
              </option>
              <option value="super" selected={role == "super"}>
                Super
              </option>
              <option value="teacher" selected={role == "teacher"}>
                Teacher
              </option>
            </select>
          </div>

          <div className="flex flex-col space-y-1">
            <p className="font-semibold text-sm text-gray-600">Password</p>
            <input
              onChange={(event) => {
                setPassword(event.target.value);
              }}
              value={password}
              type="password"
              name="password"
              className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
            />
          </div>
        </div>
        <button
          disabled={isLoading}
          type="submit"
          className="inline-flex mt-4 items-center justify-center w-max rounded-full px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-yellow-500 hover:bg-yellow-400 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
        >
          {isLoading ? (
            <span className="inline-flex text-2xl animate-spin text-white">
              <CgSpinner />
            </span>
          ) : (
            "Update"
          )}
        </button>
        {errorMessage ? (
          <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
            {errorMessage}
          </div>
        ) : null}
      </form>
    </div>
  );
};

export default EditUser;
