import db from "@lib/db";
import Handler from "@lib/handler";
import Family from "models/Family";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    if (user.role === "super" || user.role === "admin") {
      const families = await Family.find().sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        families,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  })

  //Handel post request
  .post(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (
      user.role === "super" ||
      user.role === "admin" ||
      user.role === "parent"
    ) {
      const {
        parentId,
        fatherFirstName,
        fatherLastName,
        fatherPhone,
        motherFirstName,
        motherLastName,
        motherPhone,
        city,
        state,
        zip,
        address,
      } = req.body;
      if (!parentId) {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
      await db.connect();
      const existingFamily = await Family.findOne({ parentId: parentId });
      if (existingFamily) {
        res.status(422).json({
          statusCode: 422,
          message: "A family already belongs to this parent!",
        });
        await db.disconnect();
        return;
      }

      try {
        const result = await Family.create({
          parentId,
          fatherFirstName,
          fatherLastName,
          fatherPhone,
          motherFirstName,
          motherLastName,
          motherPhone,
          city,
          state,
          zip,
          address,
        });
        res.status(201).json({
          statusCode: 201,
          message: "Family created successfully!",
        });
        await db.disconnect();
        return;
      } catch (error) {
        console.log(error);
        res.status(500).json({
          statusCode: 500,
          message: error.message,
        });
        await db.disconnect();
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel put request
  .put(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (
      user.role === "super" ||
      user.role === "admin" ||
      user.role === "parent"
    ) {
      const {
        id,
        fatherFirstName,
        fatherLastName,
        fatherPhone,
        motherFirstName,
        motherLastName,
        motherPhone,
        city,
        state,
        zip,
        address,
      } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      if (
        !fatherFirstName &&
        !fatherLastName &&
        !fatherPhone &&
        !motherFirstName &&
        !motherLastName &&
        !motherPhone &&
        !city &&
        !state &&
        !zip &&
        !address
      ) {
        res.status(422).json({
          statusCode: 422,
          message: "Nothing to update!",
        });
        return;
      }
      await db.connect();
      const familyToUpdate = await Family.findById(id);
      if (!familyToUpdate) {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Family not found!",
        });
        return;
      }
      if (fatherFirstName) {
        familyToUpdate.fatherFirstName = fatherFirstName;
      }
      if (fatherLastName) {
        familyToUpdate.fatherLastName = fatherLastName;
      }
      if (fatherPhone) {
        familyToUpdate.fatherPhone = fatherPhone;
      }
      if (motherFirstName) {
        familyToUpdate.motherFirstName = motherFirstName;
      }
      if (motherLastName) {
        familyToUpdate.motherLastName = motherLastName;
      }
      if (motherPhone) {
        familyToUpdate.motherPhone = motherPhone;
      }
      if (city) {
        familyToUpdate.city = city;
      }
      if (state) {
        familyToUpdate.state = state;
      }
      if (zip) {
        familyToUpdate.zip = zip;
      }
      if (address) {
        familyToUpdate.address = address;
      }
      await familyToUpdate.save();
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        message: "Family updated!",
      });
      return;
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel delete request
  .delete(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super" || user.role === "parent") {
      const { id } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      await db.connect();
      const familyToDelete = await Family.findById(id);
      if (familyToDelete) {
        await familyToDelete.remove();
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          message: "Family deleted!",
        });
        return;
      } else {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Family not found!",
        });
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  });
