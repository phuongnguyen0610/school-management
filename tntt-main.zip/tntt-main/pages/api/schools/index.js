import db from "@lib/db";
import Handler from "@lib/handler";
import School from "models/School";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    const schools = await School.find().sort({ createdAt: -1 });
    await db.disconnect();
    res.status(200).json({
      statusCode: 200,
      schools,
    });
  })

  //Handel post request
  .post(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super") {
      const { name, location } = req.body;
      if (
        !name ||
        !location ||
        name.trim().length > 64 ||
        location.trim().length > 128
      ) {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
      await db.connect();
      const existingSchool = await School.findOne({ name: name });
      if (existingSchool) {
        res.status(422).json({
          statusCode: 422,
          message: "Church exists already! Please choose a different name!",
        });
        await db.disconnect();
        return;
      }

      try {
        const result = await School.create({
          name,
          location,
        });
        res.status(201).json({
          statusCode: 201,
          message: "Church created successfully!",
        });
        await db.disconnect();
        return;
      } catch (error) {
        res.status(500).json({
          statusCode: 500,
          message: error.message,
        });
        await db.disconnect();
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel put request
  .put(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super") {
      const { id, name, location } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      if (!name && !location) {
        res.status(422).json({
          statusCode: 422,
          message: "Nothing to update!",
        });
        return;
      }
      await db.connect();
      const existingSchool = await School.findOne({ name: name });
      if (existingSchool) {
        res.status(422).json({
          statusCode: 422,
          message: "Church exists already! Please choose a different name!",
        });
        await db.disconnect();
        return;
      }
      const schoolToUpdate = await School.findById(id);
      if (!schoolToUpdate) {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Church not found!",
        });
        return;
      }
      if (name) {
        schoolToUpdate.name = name;
      }
      if (location) {
        schoolToUpdate.location = location;
      }
      await schoolToUpdate.save();
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        message: "Church updated!",
      });
      return;
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel delete request
  .delete(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user?.role === "super") {
      const { id } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      await db.connect();
      const schoolToDelete = await School.findById(id);
      if (schoolToDelete) {
        await schoolToDelete.remove();
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          message: "Church deleted!",
        });
        return;
      } else {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Church not found!",
        });
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  });
