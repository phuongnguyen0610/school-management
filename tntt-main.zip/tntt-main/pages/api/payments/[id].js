import db from "@lib/db";
import Handler from "@lib/handler";
import Payment from "models/Payment";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    const { id } = req.query;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (!id) {
      return res.status(422).json({
        statusCode: 422,
        message: "Invalid data!",
      });
    }
    await db.connect();
    if (user.role === "super" || user.role === "admin") {
      const payments = await Payment.find({
        familyId: id,
      }).sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        payments,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  });
