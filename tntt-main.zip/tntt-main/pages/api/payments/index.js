import db from "@lib/db";
import Handler from "@lib/handler";
import Family from "models/Family";
import Payment from "models/Payment";
import User from "models/User";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    if (user.role === "parent") {
      const parentInfo = await User.findOne({
        email: user.email,
      });
      const family = await Family.findOne({
        parentId: parentInfo._id,
      });
      if (family) {
        const payments = await Payment.find({
          familyId: family.familyId,
        }).sort({ createdAt: -1 });
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          payments,
        });
        return;
      } else {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
    }
    if (user.role === "super" || user.role === "admin") {
      const payments = await Payment.find().sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        payments,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  })

  //Handel post request
  .post(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super" || user.role === "admin") {
      const { date, method, amount, familyId, checkId, receivedBy } = req.body;
      if (!date || !method || !amount || !familyId) {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
      await db.connect();
      const existingPayment = await Payment.findOne({
        date: date,
        familyId: familyId,
        amount: amount,
      });
      if (existingPayment) {
        res.status(422).json({
          statusCode: 422,
          message: "Payment exists already!",
        });
        await db.disconnect();
        return;
      }

      try {
        const result = await Payment.create({
          date,
          method,
          amount,
          familyId,
          checkId,
          receivedBy: `${user?.name?.firstName} ${user?.name?.lastName}`,
        });
        res.status(201).json({
          statusCode: 201,
          message: "Payment added successfully!",
        });
        await db.disconnect();
        return;
      } catch (error) {
        res.status(500).json({
          statusCode: 500,
          message: error.message,
        });
        await db.disconnect();
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel put request
  .put(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super" || user.role === "admin") {
      const { id, date, method, amount, familyId, checkId, receivedBy } =
        req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      if (!date && !method && !amount && !familyId && !checkId && !receivedBy) {
        res.status(422).json({
          statusCode: 422,
          message: "Nothing to update!",
        });
        return;
      }
      await db.connect();
      const paymentToUpdate = await Payment.findById(id);
      if (!paymentToUpdate) {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Payment not found!",
        });
        return;
      }
      if (date) {
        paymentToUpdate.date = date;
      }
      if (method) {
        paymentToUpdate.method = method;
      }
      if (amount) {
        paymentToUpdate.amount = amount;
      }
      if (familyId) {
        paymentToUpdate.familyId = familyId;
      }
      if (checkId) {
        paymentToUpdate.checkId = checkId;
      }
      if (method == "cash") {
        paymentToUpdate.checkId = null;
      }
      if (receivedBy) {
        paymentToUpdate.receivedBy = receivedBy;
      }
      await paymentToUpdate.save();
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        message: "Payment updated!",
      });
      return;
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel delete request
  .delete(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user?.role === "super") {
      const { id } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      await db.connect();
      const paymentToDelete = await Payment.findById(id);
      if (paymentToDelete) {
        await paymentToDelete.remove();
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          message: "Payment deleted!",
        });
        return;
      } else {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Payment not found!",
        });
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  });
