import { hashPassword } from "@lib/auth";
import db from "@lib/db";
import User from "models/User";

export default async (req, res) => {
  if (req.method === "POST") {
    const { firstName, lastName, email, password, role } = req.body;
    if (
      !email ||
      !email.includes("@") ||
      !password ||
      !firstName ||
      !lastName ||
      password.trim().length < 6
    ) {
      return res.status(422).json({
        statusCode: 422,
        message: "Invalid data!",
      });
    }

    await db.connect();
    const existingUser = await User.findOne({ email: email });
    console.log(await User.find());
    if (existingUser) {
      res.status(422).json({
        statusCode: 422,
        message: "User exists already!",
      });
      await db.disconnect();
      return;
    }

    const hashedPassword = await hashPassword(password);
    try {
      const result = await User.create({
        firstName: firstName,
        lastName: lastName,
        email: email,
        password: hashedPassword,
        role: "parent",
      });
      res.status(201).json({
        statusCode: 201,
        message: "Account created successfully!",
      });
      await db.disconnect();
      return;
    } catch (error) {
      res.status(500).json({
        statusCode: 500,
        message: error.message,
      });
      await db.disconnect();
      return;
    }
  } else {
    res.setHeader("Allow", "POST");
    res.status(405).end("Method Not Allowed");
  }
};
