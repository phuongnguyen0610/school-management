import NextAuth from "next-auth";
import Providers from "next-auth/providers";
import db from "@lib/db";
import User from "models/User";
import { verifyPassword } from "@lib/auth";

export default NextAuth({
  session: {
    jwt: true,
    maxAge: 30 * 24 * 60 * 60,
  },
  callbacks: {
    async jwt(token, user, account, profile, isNewUser) {
      if (account?.accessToken) {
        token.accessToken = account.accessToken;
      }
      if (user?.role) {
        token.role = user.role;
      }
      return token;
    },
    async session(session, token) {
      if (token?.accessToken) {
        session.accessToken = token.accessToken;
      }
      if (token?.role) {
        session.user.role = token.role;
      }
      return session;
    },
  },
  providers: [
    Providers.Credentials({
      async authorize(credentials) {
        await db.connect();
        const user = await User.findOne({
          email: credentials.email,
        });
        if (!user) {
          await db.disconnect();
          throw new Error("No user found with the email");
        }
        const isPasswordValid = await verifyPassword(
          credentials.password,
          user.password
        );
        if (isPasswordValid) {
          await db.disconnect();
          return {
            email: user.email,
            name: { firstName: user.firstName, lastName: user.lastName },
            role: user.role,
          };
        } else {
          await db.disconnect();
          throw new Error("Password doesnt match");
        }
      },
    }),
  ],
});
