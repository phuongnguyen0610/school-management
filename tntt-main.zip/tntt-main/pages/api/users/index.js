import db from "@lib/db";
import { hashPassword } from "@lib/auth";
import Handler from "@lib/handler";
import User from "models/User";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    if (user.role === "super") {
      const users = await User.find().sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        users,
      });
    } else if (user.role === "admin") {
      const users = await User.find({
        role: { $ne: "super" },
      }).sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        users,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  })

  //Handel post request
  .post(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super") {
      const { firstName, lastName, email, password, role } = req.body;
      if (
        !email ||
        !email.includes("@") ||
        !password ||
        !firstName ||
        !lastName ||
        !role ||
        password.trim().length < 6
      ) {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
      if (user.role === "admin" && role === "super") {
        res.status(401).json({
          statusCode: 401,
          message: "Unauthorized! An admin can't create super account!",
        });
        return;
      }
      await db.connect();
      const existingUser = await User.findOne({ email: email });
      if (existingUser) {
        res.status(422).json({
          statusCode: 422,
          message: "User exists already!",
        });
        await db.disconnect();
        return;
      }

      const hashedPassword = await hashPassword(password);

      try {
        const result = await User.create({
          firstName: firstName,
          lastName: lastName,
          email: email,
          password: hashedPassword,
          role: role,
        });
        res.status(201).json({
          statusCode: 201,
          message: "User created successfully!",
        });
        await db.disconnect();
        return;
      } catch (error) {
        res.status(500).json({
          statusCode: 500,
          message: error.message,
        });
        await db.disconnect();
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel put request
  .put(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super") {
      const { id, firstName, lastName, email, password, role } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      if (!firstName && !lastName && !email && !password && !role) {
        res.status(422).json({
          statusCode: 422,
          message: "Nothing to update!",
        });
        return;
      }
      await db.connect();
      const userToUpdate = await User.findById(id);
      if (!userToUpdate) {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "User not found!",
        });
        return;
      }
      if (user.role === "admin" && userToUpdate.role === "super") {
        await db.disconnect();
        res.status(401).json({
          statusCode: 401,
          message: "Unauthorized! An admin can't edit super account!",
        });
        return;
      }
      if (userToUpdate.role === "super" && user.email !== userToUpdate.email) {
        await db.disconnect();
        res.status(401).json({
          statusCode: 401,
          message: "You can't edit super user!",
        });
        return;
      }
      if (role) {
        if (user.role === "admin" && role === "super") {
          await db.disconnect();
          res.status(401).json({
            statusCode: 401,
            message:
              "Unauthorized! You do not have sufficient privilege to perform this operation!",
          });
          return;
        }
        userToUpdate.role = role;
      }
      if (email) {
        const existingUser = await User.findOne({ email: email });
        if (existingUser) {
          res.status(422).json({
            statusCode: 422,
            message: "This email is already been used!",
          });
          await db.disconnect();
          return;
        } else {
          userToUpdate.email = email;
        }
      }
      if (firstName) {
        userToUpdate.firstName = firstName;
      }
      if (lastName) {
        userToUpdate.lastName = firstName;
      }
      if (password) {
        const hashedPassword = await hashPassword(password);
        userToUpdate.password = hashedPassword;
      }
      await userToUpdate.save();
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        message: "User updated!",
      });
      return;
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel delete request
  .delete(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user?.role === "super") {
      const { userData } = req.body;
      if (!userData) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      await db.connect();
      const userToDelete = await User.findById(userData._id);
      if (userToDelete) {
        if (user.email === userToDelete.email) {
          await db.disconnect();
          res.status(422).json({
            statusCode: 422,
            message: "You can't delete yourself!",
          });
          return;
        }
        // if (userToDelete.role === "super") {
        //   await db.disconnect();
        //   res.status(401).json({
        //     statusCode: 401,
        //     message: "You can't delete super user!",
        //   });
        //   return;
        // }
        await userToDelete.remove();
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          message: "User deleted!",
        });
        return;
      } else {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "User not found!",
        });
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  });
