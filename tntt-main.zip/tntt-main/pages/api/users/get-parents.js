import db from "@lib/db";
import Handler from "@lib/handler";
import User from "models/User";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    if (user.role === "super" || user.role === "admin") {
      const parents = await User.find({ role: "parent" }).sort({
        firstName: 1,
      });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        parents,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  });
