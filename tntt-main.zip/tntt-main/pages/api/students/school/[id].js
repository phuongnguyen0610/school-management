import db from "@lib/db";
import Handler from "@lib/handler";
import School from "models/School";
import Student from "models/Student";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    const { id } = req.query;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (!id) {
      return res.status(422).json({
        statusCode: 422,
        message: "Invalid data!",
      });
    }
    await db.connect();
    if (user.role === "super" || user.role === "admin") {
      const school = await School.findOne({
        schoolId: id,
      });
      if (!school) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        await db.disconnect();
        return;
      }
      const students = await Student.find({
        schoolName: school.name,
      }).sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        students,
        school,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  });
