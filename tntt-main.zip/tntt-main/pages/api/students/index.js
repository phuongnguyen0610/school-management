import db from "@lib/db";
import Handler from "@lib/handler";
import Family from "models/Family";
import Student from "models/Student";
import User from "models/User";

export default Handler()
  //Handel get request
  .get(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    await db.connect();
    if (user.role === "parent") {
      const parentInfo = await User.findOne({
        email: user.email,
      });
      const family = await Family.findOne({
        parentId: parentInfo._id,
      });
      if (family) {
        const students = await Student.find({
          familyId: family.familyId,
        }).sort({ createdAt: -1 });
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          students,
        });
        return;
      } else {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
    }
    if (user.role === "super" || user.role === "admin") {
      const students = await Student.find().sort({ createdAt: -1 });
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        students,
      });
    } else {
      await db.disconnect();
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
    }
  })

  //Handel post request
  .post(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (
      user.role === "super" ||
      user.role === "admin" ||
      user.role === "parent"
    ) {
      const {
        familyId,
        firstName,
        lastName,
        DOB,
        saint,
        nganh,
        schoolName,
        cap,
        year,
        age,
        gender,
        medical,
        enrolled,
        notes,
      } = req.body;
      if (!familyId || !schoolName) {
        return res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
      }
      await db.connect();
      const existingStudent = await Student.findOne({
        familyId: familyId,
        firstName: firstName,
        lastName: lastName,
        DOB: DOB,
      });
      if (existingStudent) {
        res.status(422).json({
          statusCode: 422,
          message: "Student already exists!",
        });
        await db.disconnect();
        return;
      }

      try {
        const result = await Student.create({
          familyId,
          firstName,
          lastName,
          DOB,
          saint,
          schoolName,
          age,
          gender,
          medical,
          nganh,
          cap,
          year,
          enrolled,
          notes,
        });
        res.status(201).json({
          statusCode: 201,
          message: "Student added successfully!",
        });
        await db.disconnect();
        return;
      } catch (error) {
        console.log(error);
        res.status(500).json({
          statusCode: 500,
          message: error.message,
        });
        await db.disconnect();
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel put request
  .put(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (
      user.role === "super" ||
      user.role === "admin" ||
      user.role === "parent"
    ) {
      const {
        id,
        familyId,
        firstName,
        lastName,
        DOB,
        saint,
        nganh,
        schoolName,
        cap,
        year,
        age,
        gender,
        medical,
        enrolled,
        notes,
      } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      if (
        !familyId &&
        !firstName &&
        !lastName &&
        !DOB &&
        !saint &&
        !nganh &&
        !cap &&
        !year &&
        !age &&
        !gender &&
        !schoolName &&
        typeof medical == "undefined" &&
        typeof enrolled == "undefined" &&
        !notes
      ) {
        res.status(422).json({
          statusCode: 422,
          message: "Nothing to update!",
        });
        return;
      }
      await db.connect();
      const studentToUpdate = await Student.findById(id);
      if (!studentToUpdate) {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Student not found!",
        });
        return;
      }
      if (familyId) {
        studentToUpdate.familyId = familyId;
      }
      if (firstName) {
        studentToUpdate.firstName = firstName;
      }
      if (lastName) {
        studentToUpdate.lastName = lastName;
      }
      if (DOB) {
        studentToUpdate.DOB = DOB;
      }
      if (saint) {
        studentToUpdate.saint = saint;
      }
      if (age) {
        studentToUpdate.age = age;
      }
      if (gender) {
        studentToUpdate.gender = gender;
      }
      if (nganh) {
        studentToUpdate.nganh = nganh;
      }
      if (schoolName) {
        studentToUpdate.schoolName = schoolName;
      }
      if (cap) {
        studentToUpdate.cap = cap;
      }
      if (year) {
        studentToUpdate.year = year;
      }
      studentToUpdate.medical = medical;
      if (typeof enrolled != "undefined") {
        studentToUpdate.enrolled = enrolled;
      }
      studentToUpdate.notes = notes;

      await studentToUpdate.save();
      await db.disconnect();
      res.status(200).json({
        statusCode: 200,
        message: "Student updated!",
      });
      return;
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  })

  //Handel delete request
  .delete(async (req, res) => {
    const { user } = req;
    if (!user) {
      res.status(401).json({
        statusCode: 401,
        message: "Unauthorized!",
      });
      return;
    }
    if (user.role === "super" || user.role === "parent") {
      const { id } = req.body;
      if (!id) {
        res.status(422).json({
          statusCode: 422,
          message: "Invalid data!",
        });
        return;
      }
      await db.connect();
      const studentToDelete = await Student.findById(id);
      if (studentToDelete) {
        await studentToDelete.remove();
        await db.disconnect();
        res.status(200).json({
          statusCode: 200,
          message: "Student deleted!",
        });
        return;
      } else {
        await db.disconnect();
        res.status(404).json({
          statusCode: 404,
          message: "Student not found!",
        });
        return;
      }
    } else {
      res.status(401).json({
        statusCode: 401,
        message:
          "Unauthorized! You do not have sufficient privilege to perform this operation!",
      });
      return;
    }
  });
