import { useState } from "react";
import Link from "next/link";
import { CgSpinner } from "react-icons/cg";
import { signIn } from "next-auth/client";
import toast from "react-hot-toast";
import AuthLayout from "layouts/auth";
import { useRouter } from "next/router";

const LoginPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const path = router.query["next"];
  const nextPath = path ? path : "/";
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const AuthenticateUser = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const result = await signIn("credentials", {
      redirect: false,
      email: email,
      password: password,
    });
    if (!result.error) {
      setIsLoading(false);
      setErrorMessage(null);
      toast.success("You are successfully logged in!", { duration: 4000 });
      router.push(nextPath);
    } else {
      setIsLoading(false);
      setErrorMessage("Email or password is invalid!");
    }
  };

  return (
    <div className="flex mt-6 relative min-h-screen flex-col justify-between">
      <div className="flex-grow flex justify-center items-center">
        <div className="w-full max-w-sm ">
          <div className="px-8 py-10 bg-gray-50 border border-gray-200 dark:border-gray-700 dark:bg-gray-900 rounded-2xl">
            <div className="font-serif mb-8 text-2xl font-bold text-gray-700 text-center">
              Login
            </div>
            <form onSubmit={(event) => AuthenticateUser(event)}>
              <div className="block mb-2">
                <input
                  onChange={(event) => {
                    setEmail(event.target.value);
                  }}
                  value={email}
                  name="email"
                  required
                  type="email"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="Email"
                />
              </div>
              <div className="block mb-4">
                <input
                  onChange={(event) => {
                    setPassword(event.target.value);
                  }}
                  value={password}
                  required
                  type="password"
                  name="password"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="Password"
                />
              </div>
              <button
                disabled={isLoading}
                type="submit"
                className="inline-flex items-center justify-center w-full px-10 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
              >
                {isLoading ? (
                  <span className="inline-flex text-2xl animate-spin text-white">
                    <CgSpinner />
                  </span>
                ) : (
                  "Log In"
                )}
              </button>
              {errorMessage ? (
                <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
                  {errorMessage}
                </div>
              ) : null}
            </form>
            <div className="text-center mt-2">
              <Link href="/accounts/password/reset">
                <a className="text-sm text-gray-400 dark:text-gray-200 transition duration-300 hover:text-primary">
                  Forgot password?
                </a>
              </Link>
            </div>
          </div>
          <div className="text-center mt-4 flex-none">
            Don't have an account?
            <Link href="/register">
              <a className="ml-1 text-primary">Sign up</a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

LoginPage.layout = AuthLayout;
export default LoginPage;
