import ParentLayout from "layouts/parent";
import LoadingScreen from "@components/LoadingScreen";
import { GlobalContext } from "@lib/globalContext";
import { customTableStyles, fetchGetJSON } from "@lib/healper";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import { FaSearch } from "react-icons/fa";
import { TiExport } from "react-icons/ti";
import Container from "@components/Container";
import { CSVLink } from "react-csv";

const ParentsPage = () => {
  const [students, setStudents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { doRefrash } = useContext(GlobalContext);

  const filteredStudents = students.filter((student) => {
    if (
      student.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.lasName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.schoolName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.nganh?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.familyId?.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return student;
    }
  });

  const CSVData = (filteredStudents || students).map((student) => {
    const { _id, __v, ...filteredObj } = student;
    return filteredObj;
  });

  const columns = useMemo(
    () => [
      {
        name: "ID",
        selector: (row) => `${row.studentId}`,
        sortable: true,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Name",
        selector: (row) => `${row.firstName}`,
        sortable: true,
        format: (row, index) => {
          return `${row.firstName} ${row.lastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Age",
        selector: (row) => `${row.age}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Gender",
        selector: (row) => `${row.gender}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Enrolled",
        selector: (row) => `${row.enrolled}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return (
            <span
              className={`rounded-full text-white text-opacity-80 text-xs font-medium px-2 py-0.5 block capitalize ${
                row.enrolled ? "bg-green-500" : "bg-yellow-500"
              }`}
            >
              {row.enrolled ? "Yes" : "No"}
            </span>
          );
        },
      },
      {
        name: "Church",
        selector: (row) => `${row.schoolName}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },

      {
        name: "Nganh",
        selector: (row) => `${row.nganh}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Cap",
        selector: (row) => `${row.cap}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/students");
      if (response.statusCode === 200) {
        setStudents(response?.students);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }
  return (
    <Container maxWidth="max-w-6xl">
      <div className="w-full relative">
        <div className="flex justify-between items-center my-4">
          <div className="flex items-center">
            <FaSearch className="text-lg text-primary mr-1" />
            <input
              onChange={(event) => {
                setSearchTerm(event.target.value);
              }}
              value={searchTerm}
              type="search"
              name="search"
              placeholder="Search"
              className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
            />
          </div>
          <CSVLink filename={"Children.csv"} data={CSVData}>
            <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
              <span className="hidden md:block">Export CSV</span>{" "}
              <TiExport className="block md:ml-2 text-xl" />
            </button>
          </CSVLink>
        </div>
        <DataTable
          // defaultSortFieldId="createdAt"
          columns={columns}
          data={searchTerm ? filteredStudents : students}
          customStyles={customTableStyles}
          title="All Students"
          defaultSortAsc={false}
          pagination
          highlightOnHover
          noHeader
        />
      </div>
    </Container>
  );
};

ParentsPage.auth = {
  role: ["parent"],
};

ParentsPage.layout = ParentLayout;
export default ParentsPage;
