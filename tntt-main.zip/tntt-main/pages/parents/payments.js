import ParentLayout from "layouts/parent";
import LoadingScreen from "@components/LoadingScreen";
import { GlobalContext } from "@lib/globalContext";
import { customTableStyles, fetchGetJSON, timeToString } from "@lib/healper";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import { FaSearch } from "react-icons/fa";
import { TiExport } from "react-icons/ti";
import Container from "@components/Container";
import { CSVLink } from "react-csv";

const ParentsPaymentsPage = () => {
  const [payments, setPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { doRefrash } = useContext(GlobalContext);

  const filteredPayments = payments.filter((payment) => {
    if (
      timeToString(payment.date, "MMM DD, YYYY")
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      payment.method?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.familyId?.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return payment;
    }
  });

  const CSVData = (filteredPayments || payments).map((payment) => {
    const { _id, __v, ...filteredObj } = payment;
    return filteredObj;
  });

  const columns = useMemo(
    () => [
      {
        name: "Date",
        selector: (row) => `${row.date}`,
        sortable: true,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
        format: (row, index) => {
          return timeToString(row.date, "MMM DD, YYYY");
        },
      },
      {
        name: "Payment Method",
        selector: (row) => `${row.method}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return <p className="capitalize">{row.method}</p>;
        },
      },
      {
        name: "Check ID",
        selector: (row) => `${row.checkId}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return <p>{row.checkId || "-"}</p>;
        },
      },
      {
        name: "Amount",
        selector: (row) => `${row.amount}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return <p>${row.amount}</p>;
        },
      },
      {
        name: "Paid By (Family ID)",
        selector: (row) => `${row.familyId}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return <p>{row.familyId}</p>;
        },
      },
      {
        name: "Received By",
        selector: (row) => `${row.receivedBy}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/payments");
      if (response.statusCode === 200) {
        setPayments(response?.payments);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }

  return (
    <Container maxWidth="max-w-6xl">
      <div className="w-full relative">
        <div className="flex justify-between items-center my-4">
          <div className="flex items-center">
            <FaSearch className="text-lg text-primary mr-1" />
            <input
              onChange={(event) => {
                setSearchTerm(event.target.value);
              }}
              value={searchTerm}
              type="search"
              name="search"
              placeholder="Search"
              className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
            />
          </div>
          <CSVLink filename={"Payments.csv"} data={CSVData}>
            <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
              <span className="hidden md:block">Export CSV</span>{" "}
              <TiExport className="block md:ml-2 text-xl" />
            </button>
          </CSVLink>
        </div>
        <DataTable
          // defaultSortFieldId="createdAt"
          columns={columns}
          data={searchTerm ? filteredPayments : payments}
          customStyles={customTableStyles}
          title="Payments History"
          defaultSortAsc={false}
          pagination
          highlightOnHover
          noHeader
        />
      </div>
    </Container>
  );
};

ParentsPaymentsPage.auth = {
  role: ["parent"],
};

ParentsPaymentsPage.layout = ParentLayout;
export default ParentsPaymentsPage;
