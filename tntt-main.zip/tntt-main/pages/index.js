import Hero from "@components/Home/Hero";
import { getSession } from "next-auth/client";
import { useRouter } from "next/router";
import { useEffect } from "react";

const HomePage = () => {
  const router = useRouter();
  useEffect(() => {
    getSession().then((session) => {
      if (session) {
        if (session.user?.role == "super") {
          router.push("/admin");
        } else if (session.user?.role == "admin") {
          router.push("/admin/family");
        } else if (session.user?.role == "parent") {
          router.push("/parents");
        } else {
        }
      }
    });
  }, [router]);
  return <Hero />;
};

export default HomePage;
