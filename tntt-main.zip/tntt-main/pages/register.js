import { useState } from "react";
import Link from "next/link";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchPostJSON } from "@lib/healper";
import AuthLayout from "layouts/auth";
import { signIn } from "next-auth/client";
import { useRouter } from "next/router";

const RegisterPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    const response = await fetchPostJSON("/api/auth/signup", {
      firstName,
      lastName,
      email,
      password,
    });
    if (response.statusCode === 201) {
      await signIn("credentials", {
        redirect: false,
        email: email,
        password: password,
      });
      toast.success(response.message, { duration: 4000 });
      router.push("/");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };
  return (
    <div className="flex mt-6 relative min-h-screen flex-col justify-between">
      <div className="flex-grow flex justify-center items-center">
        <div className="w-full max-w-sm ">
          <div className="px-8 py-10 bg-gray-50 border border-gray-200 dark:border-gray-700 dark:bg-gray-900 rounded-2xl">
            <div className="font-serif mb-8 text-3xl text-gray-700 font-bold text-center">
              Register
            </div>
            <form onSubmit={onSubmit}>
              <div className="block mb-2">
                <input
                  onChange={(event) => {
                    setFirstName(event.target.value);
                  }}
                  value={firstName}
                  required
                  type="text"
                  name="fname"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="First Name"
                />
              </div>
              <div className="block mb-2">
                <input
                  onChange={(event) => {
                    setLastName(event.target.value);
                  }}
                  value={lastName}
                  required
                  type="text"
                  name="lname"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="Last Name"
                />
              </div>
              <div className="block mb-2">
                <input
                  onChange={(event) => {
                    setEmail(event.target.value);
                  }}
                  value={email}
                  name="email"
                  required
                  type="email"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="Email"
                />
              </div>

              <div className="block mb-4">
                <input
                  onChange={(event) => {
                    setPassword(event.target.value);
                  }}
                  value={password}
                  required
                  type="password"
                  name="password"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                  placeholder="Password"
                />
              </div>
              <button
                disabled={isLoading}
                type="submit"
                className="inline-flex items-center justify-center w-full px-10 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
              >
                {isLoading ? (
                  <span className="inline-flex text-2xl animate-spin text-white">
                    <CgSpinner />
                  </span>
                ) : (
                  "Sign up"
                )}
              </button>
              <div className="text-center py-2 text-gray-400 text-sm">
                By signing up, you agree to our{" "}
                <Link href="/legal/terms">
                  <a className="font-medium text-gray-500 dark:text-gray-300 transition-colors duration-300 hover:text-primary">
                    Terms
                  </a>
                </Link>{" "}
                ,{" "}
                <Link href="/legal/privacy">
                  <a className="font-medium text-gray-500 dark:text-gray-300 transition-colors duration-300 hover:text-primary">
                    Privacy Policy
                  </a>
                </Link>{" "}
                and{" "}
                <Link href="/legal/cookies">
                  <a className="font-medium text-gray-500 dark:text-gray-300 transition-colors duration-300 hover:text-primary">
                    Cookies Policy
                  </a>
                </Link>{" "}
                .
              </div>
              {errorMessage ? (
                <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
                  {errorMessage}
                </div>
              ) : null}
            </form>
          </div>
          <div className="text-center mt-4 flex-none">
            Already a member?
            <Link href="/login">
              <a className="ml-1 text-primary">Sign in</a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

RegisterPage.layout = AuthLayout;
export default RegisterPage;
