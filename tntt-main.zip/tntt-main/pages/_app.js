import { Toaster } from "react-hot-toast";
import DefaultLayout from "../layouts/default";
// import NextNprogress from "nextjs-progressbar";
import "../styles/globals.css";
import "../styles/react-search-select.css";
import { Fragment } from "react";
import { Provider } from "next-auth/client";
import RequiredAuth from "@lib/requiredAuth";
import GlobalContextProvider from "@lib/globalContext";

function MyApp({ Component, pageProps, router }) {
  const Layout = Component.layout || DefaultLayout;
  const Title = Component.title || null;
  const CTA = Component.cta || null;
  return (
    <Fragment>
      <Provider session={pageProps.session}>
        <GlobalContextProvider>
          <Toaster />
          {Component.auth ? (
            <RequiredAuth role={Component.auth.role}>
              <Layout title={Title} cta={CTA} key={router.route}>
                <Component {...pageProps} />
              </Layout>
            </RequiredAuth>
          ) : (
            <Layout key={router.route}>
              <Component {...pageProps} />
            </Layout>
          )}
        </GlobalContextProvider>
      </Provider>
    </Fragment>
  );
}

export default MyApp;
