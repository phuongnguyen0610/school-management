const HelpPage = () => {
  return (
    <div className="w-full h-screen fixed inset-0 flex flex-col justify-center items-center">
      <img className="mb-8" src="/img/svg/help.svg" width={400} />
      <h1 className="text-4xl text-pink-700 font-bold">Need Help?</h1>
      <div>
        <p className="font-semibold inline">Please contact at </p>{" "}
        <a
          href="mailto:nguyenthiquy@gmail.com"
          className="text-primary underline font-semibold inline"
        >
          hangphuongute@gmail.com
        </a>
      </div>
    </div>
  );
};

export default HelpPage;
