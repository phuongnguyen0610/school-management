import AccessDenied from "@components/AccessDenied";

const Page403 = () => {
  return <AccessDenied />;
};

export default Page403;
