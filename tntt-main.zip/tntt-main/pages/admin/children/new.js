import AdminLayout from "layouts/admin";
import { useEffect, useState } from "react";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchGetJSON, fetchPostJSON, getAge } from "@lib/healper";
import { useRouter } from "next/router";
import SelectSearch, { fuzzySearch } from "react-select-search-nextjs";
import Toggle from "@components/Toggle";

const AdminNewStudentPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [familyId, setFamilyId] = useState("");
  const [schoolName, setSchoolName] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [DOB, setDOB] = useState("");
  const [saint, setSaint] = useState("");
  const [nganh, setNganh] = useState("");
  const [cap, setCap] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [medical, setMedical] = useState("");
  const [year, setYear] = useState(new Date().getFullYear());
  const [enrolled, setEnrolled] = useState(false);
  const [notes, setNotes] = useState("");
  const [families, setFamilies] = useState([]);
  const [schools, setSchools] = useState([]);
  const router = useRouter();

  const nganhList = ["Au Nhi", "Thieu Nhi", "Nghia Si", "Hiep Si"];

  const onSubmit = async (event) => {
    event.preventDefault();
    if (!familyId || !schoolName) {
      toast.error("Please provide all the information!");
      return;
    }
    if (age < 7 || age > 18) {
      return toast.error("Age should be between 7-18!");
    }
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPostJSON("/api/students", {
      familyId,
      firstName,
      lastName,
      DOB,
      schoolName,
      saint,
      nganh,
      cap,
      year,
      age,
      gender,
      medical,
      enrolled,
      notes,
    });
    if (response.statusCode === 201) {
      toast.success(response.message, { duration: 4000 });
      router.push("/admin/children");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  const toggleEnrolled = () => {
    setEnrolled(!enrolled);
  };

  const getNganh = (age) => {
    if (age < 7 || age > 18) {
      return "";
    }
    if (age >= 7 && age <= 9) {
      return nganhList[0];
    } else if (age >= 10 && age <= 12) {
      return nganhList[1];
    } else if (age >= 13 && age <= 15) {
      return nganhList[2];
    } else if (age >= 16 && age <= 18) {
      return nganhList[3];
    } else {
      return "";
    }
  };

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/family");
      if (response.statusCode === 200) {
        setFamilies(response?.families);
      }
      const response_schools = await fetchGetJSON("/api/schools");
      if (response_schools.statusCode === 200) {
        setSchools(response_schools?.schools);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, []);

  useEffect(() => {
    const unsubs = async () => {
      if (DOB) {
        const currentAge = getAge(DOB);
        if (currentAge > 0) {
          setAge(currentAge);
        } else {
          setAge(0);
        }
      }
    };
    return unsubs();
  }, [DOB]);

  useEffect(() => {
    const unsubs = async () => {
      if (age) {
        const currentCap = age % 3;
        if (currentCap === 0) {
          setCap(3);
        } else {
          setCap(currentCap);
        }
      } else {
        setCap("");
      }

      setNganh(getNganh(age));
    };
    return unsubs();
  }, [age]);

  const options = families.map((family) => ({
    name: `ID : ${family.familyId} - Father :  ${family.fatherFirstName} ${family.fatherLastName}`,
    value: family.familyId,
  }));

  const options_schools = schools.map((school) => ({
    name: `${school.schoolId} - ${school.name}`,
    value: school.name,
  }));

  return (
    <div className="w-full lg:my-8 ">
      <img
        src="/img/svg/new.svg"
        className="fixed right-0 bottom-0 max-w-lg z-0 hidden md:block"
      />
      <div className="px-8 max-w-3xl w-full py-16 mx-auto md:mx-0 border-gray-200 sm:shadow-card rounded-2xl z-10 bg-white relative">
        <form onSubmit={onSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">First Name</p>
              <input
                onChange={(event) => {
                  setFirstName(event.target.value);
                }}
                value={firstName}
                required
                type="text"
                name="fname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Last Name</p>
              <input
                onChange={(event) => {
                  setLastName(event.target.value);
                }}
                value={lastName}
                required
                type="text"
                name="lname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Saint</p>
              <input
                onChange={(event) => {
                  setSaint(event.target.value);
                }}
                value={saint}
                required
                type="text"
                name="saint"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Date of Birth
              </p>
              <input
                onChange={(event) => {
                  setDOB(event.target.value);
                }}
                value={DOB}
                required
                type="date"
                name="dob"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Age</p>
              <input
                onChange={(event) => {
                  setAge(event.target.value);
                }}
                value={age}
                readOnly
                required
                type="number"
                name="age"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Gender</p>
              <select
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                required
                name="gender"
                onChange={(event) => {
                  setGender(event.target.value);
                }}
              >
                <option disabled value="" selected>
                  ...
                </option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="unknown">Prefer not to say</option>
              </select>
            </div>

            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Church</p>
              <SelectSearch
                onChange={setSchoolName}
                options={options_schools}
                name="school"
                search
                filterOptions={fuzzySearch}
                emptyMessage="Not found"
                placeholder="Choose..."
              />
            </div>

            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600 line-clamp-1">
                Nganh
              </p>
              <input
                onChange={(event) => {
                  setNganh(event.target.value);
                }}
                readOnly
                required
                value={nganh}
                type="text"
                name="nganh"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600 line-clamp-1">
                Cap
              </p>
              <input
                onChange={(event) => {
                  setCap(event.target.value);
                }}
                readOnly
                required
                value={cap}
                type="text"
                name="cap"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex space-x-2">
              <div className="flex flex-col space-y-1 flex-1">
                <p className="font-semibold text-sm text-gray-600 line-clamp-1">
                  Year
                </p>
                <input
                  onChange={(event) => {
                    setYear(event.target.value);
                  }}
                  required
                  value={year}
                  type="text"
                  name="year"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                />
              </div>
              <div className="flex flex-col space-y-1">
                <p className="font-semibold text-sm text-gray-600 mb-1">
                  Enrolled
                </p>
                <Toggle enabled={enrolled} onChange={toggleEnrolled} />
              </div>
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600 line-clamp-1">
                Allergies/Medical Problems/Disabilities
              </p>
              <input
                onChange={(event) => {
                  setMedical(event.target.value);
                }}
                value={medical}
                type="text"
                name="medical"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Family ID </p>

              <SelectSearch
                onChange={setFamilyId}
                options={options}
                name="family"
                search
                filterOptions={fuzzySearch}
                emptyMessage="Not found"
                placeholder="Choose..."
              />
            </div>
            <div className="flex flex-col space-y-1 md:col-span-2">
              <p className="font-semibold text-sm text-gray-600">Notes</p>
              <textarea
                onChange={(event) => {
                  setNotes(event.target.value);
                }}
                value={notes}
                type="text"
                name="notes"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
          </div>
          <button
            disabled={isLoading}
            type="submit"
            className="inline-flex mt-4 w-max items-center justify-center px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
          >
            {isLoading ? (
              <span className="inline-flex text-2xl animate-spin text-white">
                <CgSpinner />
              </span>
            ) : (
              "Submit"
            )}
          </button>
          {errorMessage ? (
            <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
              {errorMessage}
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
};

AdminNewStudentPage.auth = {
  role: ["super", "admin"],
};
AdminNewStudentPage.layout = AdminLayout;
AdminNewStudentPage.title = "Add New Child";
export default AdminNewStudentPage;