import LoadingScreen from "@components/LoadingScreen";
import EditStudent from "@components/Student/Edit";
import { GlobalContext } from "@lib/globalContext";
import {
  customTableStyles,
  fetchDeleteJSON,
  fetchGetJSON,
  timeToString,
} from "@lib/healper";
import AdminLayout from "layouts/admin";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import toast from "react-hot-toast";
import { FaSearch } from "react-icons/fa";
import { FiTrash2 } from "react-icons/fi";
import { AiOutlineUserAdd } from "react-icons/ai";
import { TiExport } from "react-icons/ti";
import { CSVLink } from "react-csv";

const AdminStudentPage = () => {
  const [students, setStudents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isBusy, setIsBusy] = useState(false);
  const { doRefrash } = useContext(GlobalContext);

  const rosterSearch = searchTerm?.split(",");

  const deleteStudent = async (studentData) => {
    const userAction = confirm(`Are you sure you want to delete this student?`);
    if (userAction) {
      const Request = async () => {
        setIsBusy(true);
        const response = await fetchDeleteJSON("/api/students", {
          id: studentData._id,
        });
        if (response.statusCode === 200) {
          setStudents((students) => {
            return students.filter(
              (student) => student._id !== studentData._id
            );
          });
          setIsBusy(false);
          return response.message;
        } else {
          setIsBusy(false);
          throw new Error(response.message);
        }
      };
      toast.promise(Request(), {
        loading: <b>Loading...</b>,
        success: (data) => <b>{data}</b>,
        error: (err) => <b>{err.toString()}</b>,
      });
    }
  };
  const deleteButton = (studentData) => {
    return (
      <button
        disabled={isBusy}
        onClick={() => deleteStudent(studentData)}
        title="Delete this student"
        className="text-pink-600 text-lg"
      >
        <FiTrash2 />
      </button>
    );
  };
  const filteredStudents =
    rosterSearch.length > 1
      ? students.filter((student) => {
          if (
            student.nganh
              ?.toLowerCase()
              .includes(rosterSearch[0]?.toLowerCase().trim()) &&
            student.cap.includes(rosterSearch[1]?.trim())
          ) {
            return student;
          }
        })
      : students.filter((student) => {
          if (
            student.firstName
              ?.toLowerCase()
              .includes(searchTerm.toLowerCase()) ||
            student.lasName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            student.schoolName
              ?.toLowerCase()
              .includes(searchTerm.toLowerCase()) ||
            student.year == searchTerm ||
            student.nganh?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            student.familyId?.toLowerCase().includes(searchTerm.toLowerCase())
          ) {
            return student;
          }
        });

  const CSVData = (filteredStudents || students).map((student) => {
    const { _id, __v, ...filteredObj } = student;
    return filteredObj;
  });

  const columns = useMemo(
    () => [
      {
        name: "ID",
        selector: (row) => `${row.studentId}`,
        sortable: true,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Name",
        selector: (row) => `${row.firstName}`,
        sortable: true,
        format: (row, index) => {
          return `${row.firstName} ${row.lastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      // {
      //   name: "Date of Birth",
      //   selector: (row) => `${row.DOB}`,
      //   sortable: true,
      //   format: (row, index) => {
      //     return timeToString(row.DOB, "MMM DD, YYYY");
      //   },
      //   style: {
      //     color: "rgba(0,0,0,.54)",
      //   },
      // },
      {
        name: "Age",
        selector: (row) => `${row.age}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Gender",
        selector: (row) => `${row.gender}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Enrolled",
        selector: (row) => `${row.enrolled}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
        format: (row, index) => {
          return (
            <span
              className={`rounded-full text-white text-opacity-80 text-xs font-medium px-2 py-0.5 block capitalize ${
                row.enrolled ? "bg-green-500" : "bg-yellow-500"
              }`}
            >
              {row.enrolled ? "Yes" : "No"}
            </span>
          );
        },
      },
      {
        name: "Church",
        selector: (row) => `${row.schoolName}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },

      {
        name: "Nganh",
        selector: (row) => `${row.nganh}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Cap",
        selector: (row) => `${row.cap}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },

      // {
      //   name: "Created At",
      //   selector: (row) => `${row.createdAt}`,
      //   sortable: true,
      //   format: (row, index) => {
      //     return timeToString(row.createdAt, "MMM DD, YYYY");
      //   },
      //   style: {
      //     color: "rgba(0,0,0,.54)",
      //   },
      // },
      {
        cell: (row) => deleteButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/students");
      if (response.statusCode === 200) {
        setStudents(response?.students);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }
  return (
    <div className="w-full relative">
      <div className="flex justify-between items-center my-4">
        <div className="flex items-center">
          <FaSearch className="text-lg text-primary mr-1" />
          <input
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
            value={searchTerm}
            type="search"
            name="search"
            placeholder="Search"
            className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
          />
        </div>
        <a href="/admin/children/new">
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Add New Child</span>{" "}
            <AiOutlineUserAdd className="block md:ml-2 text-xl" />
          </button>
        </a>
        <CSVLink filename={"Children.csv"} data={CSVData}>
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Export CSV</span>{" "}
            <TiExport className="block md:ml-2 text-xl" />
          </button>
        </CSVLink>
      </div>
      <DataTable
        // defaultSortFieldId="createdAt"
        columns={columns}
        data={searchTerm ? filteredStudents : students}
        customStyles={customTableStyles}
        title="All Students"
        expandableRows
        expandableRowsComponent={EditStudent}
        defaultSortAsc={false}
        pagination
        highlightOnHover
        noHeader
      />
    </div>
  );
};

AdminStudentPage.auth = {
  role: ["super", "admin", "teacher"],
};
AdminStudentPage.layout = AdminLayout;
AdminStudentPage.title = "Children";
AdminStudentPage.cta = {
  title: "Add Child",
  url: "/admin/children/new",
};
export default AdminStudentPage;