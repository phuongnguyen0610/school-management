import AdminLayout from "layouts/admin";
import { useEffect, useState } from "react";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchGetJSON, fetchPostJSON } from "@lib/healper";
import { useRouter } from "next/router";
import SelectSearch, { fuzzySearch } from "react-select-search-nextjs";

const AdminNewFamilyPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [parentId, setParentId] = useState("");
  const [fatherFirstName, setFatherFirstName] = useState("");
  const [fatherLastName, setFatherLastName] = useState("");
  const [fatherPhone, setFatherPhone] = useState("");
  const [motherFirstName, setMotherFirstName] = useState("");
  const [motherLastName, setMotherLastName] = useState("");
  const [motherPhone, setMotherPhone] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [zip, setZip] = useState("");
  const [address, setAddress] = useState("");
  const [parents, setParents] = useState([]);
  const router = useRouter();

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPostJSON("/api/family", {
      parentId,
      fatherFirstName,
      fatherLastName,
      fatherPhone,
      motherFirstName,
      motherLastName,
      motherPhone,
      city,
      state,
      zip,
      address,
    });
    if (response.statusCode === 201) {
      toast.success(response.message, { duration: 4000 });
      router.push("/admin/family");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/users/get-parents");
      if (response.statusCode === 200) {
        setParents(response?.parents);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, []);

  const options = parents.map((parent) => ({
    name: `ID : ${parent.userId} - ${parent.firstName} ${parent.lastName}`,
    value: parent._id,
  }));
  return (
    <div className="w-full lg:my-8 ">
      <img
        src="/img/svg/new.svg"
        className="fixed right-0 bottom-0 max-w-lg z-0 hidden md:block"
      />
      <div className="px-8 max-w-3xl w-full py-16 mx-auto md:mx-0 border-gray-200 sm:shadow-card rounded-2xl z-10 bg-white relative">
        <form onSubmit={onSubmit}>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Father's First Name
              </p>
              <input
                onChange={(event) => {
                  setFatherFirstName(event.target.value);
                }}
                value={fatherFirstName}
                required
                type="text"
                name="fname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Father's Last Name
              </p>
              <input
                onChange={(event) => {
                  setFatherLastName(event.target.value);
                }}
                value={fatherLastName}
                required
                type="text"
                name="lname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Father's Phone
              </p>
              <input
                onChange={(event) => {
                  setFatherPhone(event.target.value);
                }}
                value={fatherPhone}
                type="tel"
                name="phone"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Mother's First Name
              </p>
              <input
                onChange={(event) => {
                  setMotherFirstName(event.target.value);
                }}
                value={motherFirstName}
                required
                type="text"
                name="fname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Mother's Last Name
              </p>
              <input
                onChange={(event) => {
                  setMotherLastName(event.target.value);
                }}
                value={motherLastName}
                required
                type="text"
                name="lname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Mother's Phone
              </p>
              <input
                onChange={(event) => {
                  setMotherPhone(event.target.value);
                }}
                value={motherPhone}
                type="tel"
                name="phone"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Parents ID{" "}
                <span className="text-gray-400 font-normal">
                  (Owner of this family)
                </span>
              </p>

              <SelectSearch
                onChange={setParentId}
                options={options}
                name="language"
                search
                filterOptions={fuzzySearch}
                emptyMessage="Not found"
                placeholder="Choose..."
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">City</p>
              <input
                onChange={(event) => {
                  setCity(event.target.value);
                }}
                value={city}
                required
                type="text"
                name="city"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">State</p>
              <input
                onChange={(event) => {
                  setState(event.target.value);
                }}
                value={state}
                required
                type="text"
                name="state"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Zip</p>
              <input
                onChange={(event) => {
                  setZip(event.target.value);
                }}
                value={zip}
                required
                type="text"
                name="zip"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Address</p>
              <input
                onChange={(event) => {
                  setAddress(event.target.value);
                }}
                value={address}
                required
                type="text"
                name="address"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
          </div>
          <button
            disabled={isLoading}
            type="submit"
            className="inline-flex mt-4 w-max items-center justify-center px-16 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
          >
            {isLoading ? (
              <span className="inline-flex text-2xl animate-spin text-white">
                <CgSpinner />
              </span>
            ) : (
              "Submit"
            )}
          </button>
          {errorMessage ? (
            <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
              {errorMessage}
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
};

AdminNewFamilyPage.auth = {
  role: ["super", "admin"],
};
AdminNewFamilyPage.layout = AdminLayout;
AdminNewFamilyPage.title = "Add New Family";
export default AdminNewFamilyPage;