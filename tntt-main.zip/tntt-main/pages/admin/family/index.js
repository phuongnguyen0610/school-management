import EditFamily from "@components/Family/View_Children";
import LoadingScreen from "@components/LoadingScreen";
import { GlobalContext } from "@lib/globalContext";
import {
  customTableStyles,
  fetchDeleteJSON,
  fetchGetJSON,
  timeToString,
} from "@lib/healper";
import AdminLayout from "layouts/admin";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import toast from "react-hot-toast";
import { FaSearch } from "react-icons/fa";
import { FiTrash2 } from "react-icons/fi";
import { AiOutlineUsergroupAdd } from "react-icons/ai";
import { TiExport } from "react-icons/ti";
import { CSVLink } from "react-csv";
import { BsEyeFill } from "react-icons/bs";
import Link from "next/link";

const AdminFamilyPage = () => {
  const [families, setFamilies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isBusy, setIsBusy] = useState(false);
  const { doRefrash } = useContext(GlobalContext);

  const deleteFamily = async (familyData) => {
    const userAction = confirm(`Are you sure you want to delete this family?`);
    if (userAction) {
      const Request = async () => {
        setIsBusy(true);
        const response = await fetchDeleteJSON("/api/family", {
          id: familyData._id,
        });
        if (response.statusCode === 200) {
          setFamilies((families) => {
            return families.filter((family) => family._id !== familyData._id);
          });
          setIsBusy(false);
          return response.message;
        } else {
          setIsBusy(false);
          throw new Error(response.message);
        }
      };
      toast.promise(Request(), {
        loading: <b>Loading...</b>,
        success: (data) => <b>{data}</b>,
        error: (err) => <b>{err.toString()}</b>,
      });
    }
  };
  const deleteButton = (familyData) => {
    return (
      <button
        disabled={isBusy}
        onClick={() => deleteFamily(familyData)}
        title="Delete this family"
        className="text-pink-600 text-lg"
      >
        <FiTrash2 />
      </button>
    );
  };
  const viewButton = (familyData) => {
    return (
      <Link href={`/admin/family/${familyData.familyId}`}>
        <a className="text-green-600 text-lg">
          <BsEyeFill />
        </a>
      </Link>
    );
  };
  const filteredFamilies = families.filter((family) => {
    if (
      family.fatherFirstName
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      family.fatherLastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.fatherPhone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.motherFirstName
        ?.toLowerCase()
        .includes(searchTerm.toLowerCase()) ||
      family.motherLastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.motherPhone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.state?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.zip?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      family.address?.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return family;
    }
  });

  const CSVData = (filteredFamilies || families).map((family) => {
    const { _id, __v, ...filteredObj } = family;
    return filteredObj;
  });

  const columns = useMemo(
    () => [
      {
        cell: (row) => viewButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
      // {
      //   cell: (row) => editButton(row),
      //   allowOverflow: true,
      //   button: true,
      //   width: "56px",
      // },
      // {
      //   cell: (row) => deleteButton(row),
      //   allowOverflow: true,
      //   button: true,
      //   width: "56px",
      // },
      {
        name: "ID",
        selector: (row) => `${row.familyId}`,
        sortable: true,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Father",
        selector: (row) => `${row.fatherFirstName}`,
        sortable: true,
        format: (row, index) => {
          return `${row.fatherFirstName} ${row.fatherLastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Father's Phone",
        selector: (row) => `${row.fatherPhone}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Mother",
        selector: (row) => `${row.motherFirstName}`,
        sortable: true,
        format: (row, index) => {
          return `${row.motherFirstName} ${row.motherLastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Mother's Phone",
        selector: (row) => `${row.motherPhone}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Address",
        selector: (row) => `${row.address}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "City",
        selector: (row) => `${row.city}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "State",
        selector: (row) => `${row.state}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Zip",
        selector: (row) => `${row.zip}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },

      {
        name: "Created At",
        selector: (row) => `${row.createdAt}`,
        sortable: true,
        format: (row, index) => {
          return timeToString(row.createdAt, "MMM DD, YYYY");
        },
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/family");
      if (response.statusCode === 200) {
        setFamilies(response?.families);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }
  return (
    <div className="w-full relative">
      <div className="flex justify-between items-center my-4">
        <div className="flex items-center">
          <FaSearch className="text-lg text-primary mr-1" />
          <input
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
            value={searchTerm}
            type="search"
            name="search"
            placeholder="Search"
            className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
          />
        </div>
        <a href="/admin/family/new">
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Add New Family</span>{" "}
            <AiOutlineUsergroupAdd className="block md:ml-2 text-xl" />
          </button>
        </a>
        <CSVLink filename={"Families.csv"} data={CSVData}>
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Export CSV</span>{" "}
            <TiExport className="block md:ml-2 text-xl" />
          </button>
        </CSVLink>
      </div>
      <DataTable
        // defaultSortFieldId="createdAt"
        columns={columns}
        data={searchTerm ? filteredFamilies : families}
        customStyles={customTableStyles}
        title="All Families"
        expandableRows
        expandableRowsComponent={EditFamily}
        defaultSortAsc={false}
        pagination
        highlightOnHover
        noHeader
      />
    </div>
  );
};

AdminFamilyPage.auth = {
  role: ["super", "admin"],
};
AdminFamilyPage.layout = AdminLayout;
AdminFamilyPage.title = "Families";
AdminFamilyPage.cta = {
  title: "Add Family",
  url: "/admin/family/new",
};
export default AdminFamilyPage;
