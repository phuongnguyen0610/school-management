import LoadingScreen from "@components/LoadingScreen";
import EditUser from "@components/User/Edit";
import { GlobalContext } from "@lib/globalContext";
import {
  customTableStyles,
  fetchDeleteJSON,
  fetchGetJSON,
  timeToString,
} from "@lib/healper";
import AdminLayout from "layouts/admin";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import toast from "react-hot-toast";
import { FaSearch } from "react-icons/fa";
import { FiTrash2 } from "react-icons/fi";
import { TiExport } from "react-icons/ti";
import { CSVLink } from "react-csv";

const AdminPage = () => {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isBusy, setIsBusy] = useState(false);
  const { doRefrash } = useContext(GlobalContext);

  const deleteUser = async (userData) => {
    const userAction = confirm(
      `Are you sure you want to delete ${userData.firstName} ${userData.lastName}?`
    );
    if (userAction) {
      const Request = async () => {
        setIsBusy(true);
        const response = await fetchDeleteJSON("/api/users", { userData });
        if (response.statusCode === 200) {
          setUsers((usrs) => {
            return usrs.filter((usr) => usr._id !== userData._id);
          });
          setIsBusy(false);
          return response.message;
        } else {
          setIsBusy(false);
          throw new Error(response.message);
        }
      };
      toast.promise(Request(), {
        loading: <b>Loading...</b>,
        success: (data) => <b>{data}</b>,
        error: (err) => <b>{err.toString()}</b>,
      });
    }
  };
  const deleteButton = (userData) => {
    return (
      <button
        disabled={isBusy}
        onClick={() => deleteUser(userData)}
        title="Delete this user"
        className="text-pink-600 text-lg"
      >
        <FiTrash2 />
      </button>
    );
  };
  const filteredUsers = users.filter((user) => {
    if (
      user.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.role?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email?.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return user;
    }
  });
  const CSVData = (filteredUsers || users).map((user) => {
    const { password, __v, ...filteredObj } = user;
    return filteredObj;
  });
  const columns = useMemo(
    () => [
      {
        name: "ID",
        selector: (row) => `${row.userId}`,
        sortable: true,
        width: "96px",
        format: (row, index) => {
          return `${row.userId || "-"}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Name",
        selector: (row) => `${row.firstName}`,
        sortable: true,
        format: (row, index) => {
          return `${row.firstName} ${row.lastName}`;
        },
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "Email",
        selector: (row) => `${row.email}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Role",
        selector: (row) => `${row.role}`,
        sortable: true,
        format: (row, index) => {
          return (
            <span
              className={`rounded-full text-white text-opacity-80 text-xs font-medium px-2 py-0.5 block capitalize ${
                row.role == "super"
                  ? "bg-red-500"
                  : row.role == "admin"
                  ? "bg-yellow-500"
                  : row.role == "teacher"
                  ? "bg-primary"
                  : "bg-indigo-500"
              }`}
            >
              {row.role}
            </span>
          );
        },
      },
      {
        name: "Created At",
        selector: (row) => `${row.createdAt}`,
        sortable: true,
        format: (row, index) => {
          return timeToString(row.createdAt, "MMM DD, YYYY");
        },
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        cell: (row) => deleteButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/users");
      if (response.statusCode === 200) {
        setUsers(response?.users);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }
  return (
    <div className="w-full relative">
      <div className="flex justify-between items-center my-4">
        <div className="flex items-center">
          <FaSearch className="text-lg text-primary mr-1" />
          <input
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
            value={searchTerm}
            type="search"
            name="search"
            placeholder="Search"
            className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
          />
        </div>
        <CSVLink filename={"Users.csv"} data={CSVData}>
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Export CSV</span>{" "}
            <TiExport className="block md:ml-2 text-xl" />
          </button>
        </CSVLink>
      </div>
      <DataTable
        // defaultSortFieldId="createdAt"
        columns={columns}
        data={searchTerm ? filteredUsers : users}
        customStyles={customTableStyles}
        title="All Users"
        expandableRows
        expandableRowsComponent={EditUser}
        defaultSortAsc={false}
        pagination
        highlightOnHover
        noHeader
      />
    </div>
  );
};

AdminPage.auth = {
  role: ["super"],
};
AdminPage.layout = AdminLayout;
AdminPage.title = "Users";
AdminPage.cta = {
  title: "Add user",
  url: "/admin/users/new",
};
export default AdminPage;