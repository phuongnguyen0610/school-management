import AdminLayout from "layouts/admin";
import LoadingScreen from "@components/LoadingScreen";
import {
  customTableStyles,
  fetchDeleteJSON,
  fetchGetJSON,
  timeToString,
} from "@lib/healper";
import { useState, useEffect, useMemo, useContext } from "react";
import DataTable from "react-data-table-component";
import toast from "react-hot-toast";
import { FaSearch } from "react-icons/fa";
import { BsEyeFill } from "react-icons/bs";
import { FiTrash2 } from "react-icons/fi";
import { TiExport } from "react-icons/ti";
import EditSchool from "@components/School/Edit";
import { GlobalContext } from "@lib/globalContext";
import Link from "next/link";
import { CSVLink } from "react-csv";

const AdminSchoolsPage = () => {
  const [schools, setSchools] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [isBusy, setIsBusy] = useState(false);
  const { doRefrash } = useContext(GlobalContext);

  const deleteSchool = async (schoolData) => {
    const userAction = confirm(
      `Are you sure you want to delete ${schoolData.name}?`
    );
    if (userAction) {
      const Request = async () => {
        setIsBusy(true);
        const response = await fetchDeleteJSON("/api/schools", {
          id: schoolData._id,
        });
        if (response.statusCode === 200) {
          setSchools((schools) => {
            return schools.filter((school) => school._id !== schoolData._id);
          });
          setIsBusy(false);
          return response.message;
        } else {
          setIsBusy(false);
          throw new Error(response.message);
        }
      };
      toast.promise(Request(), {
        loading: <b>Loading...</b>,
        success: (data) => <b>{data}</b>,
        error: (err) => <b>{err.toString()}</b>,
      });
    }
  };
  const deleteButton = (schoolData) => {
    return (
      <button
        disabled={isBusy}
        onClick={() => deleteSchool(schoolData)}
        title="Delete school"
        className="text-pink-600 text-lg"
      >
        <FiTrash2 />
      </button>
    );
  };
  const viewButton = (schoolData) => {
    return (
      <Link href={`/admin/churches/${schoolData.schoolId}`}>
        <a className="text-green-600 text-lg">
          <BsEyeFill />
        </a>
      </Link>
    );
  };

  const filteredSchools = schools.filter((school) => {
    if (
      school.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      school.location?.toLowerCase().includes(searchTerm.toLowerCase())
    ) {
      return school;
    }
  });

  const CSVData = (filteredSchools || schools).map((school) => {
    const { _id, __v, ...filteredObj } = school;
    return filteredObj;
  });

  const columns = useMemo(
    () => [
      {
        name: "Name",
        selector: (row) => `${row.name}`,
        sortable: true,
        style: {
          color: "#202124",
          fontSize: "14px",
          fontWeight: 500,
        },
      },
      {
        name: "School ID",
        selector: (row) => `${row.schoolId}`,
        sortable: true,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Location",
        selector: (row) => `${row.location}`,
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        name: "Created At",
        selector: (row) => `${row.createdAt}`,
        sortable: true,
        format: (row, index) => {
          return timeToString(row.createdAt, "MMM DD, YYYY");
        },
        style: {
          color: "rgba(0,0,0,.54)",
        },
      },
      {
        cell: (row) => viewButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
      {
        cell: (row) => deleteButton(row),
        allowOverflow: true,
        button: true,
        width: "56px",
      },
    ],
    []
  );

  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/schools");
      if (response.statusCode === 200) {
        setSchools(response?.schools);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [doRefrash]);

  if (isLoading) {
    return <LoadingScreen fullScreen={false} />;
  }

  return (
    <div className="w-full relative">
      <div className="flex justify-between items-center my-4">
        <div className="flex items-center">
          <FaSearch className="text-lg text-primary mr-1" />
          <input
            onChange={(event) => {
              setSearchTerm(event.target.value);
            }}
            value={searchTerm}
            type="search"
            name="search"
            placeholder="Search"
            className="border-0 border-b-2 border-gray-200 focus:ring-0 focus:border-primary duration-300 transition-colors"
          />
        </div>
        <CSVLink filename={"Churches.csv"} data={CSVData}>
          <button className="bg-primary flex items-center text-white font-medium text-sm px-4 py-2 rounded duration-300 hover:bg-pink-300">
            <span className="hidden md:block">Export CSV</span>{" "}
            <TiExport className="block md:ml-2 text-xl" />
          </button>
        </CSVLink>
      </div>
      <DataTable
        // defaultSortFieldId="createdAt"
        columns={columns}
        data={searchTerm ? filteredSchools : schools}
        customStyles={customTableStyles}
        title="All Schools"
        expandableRows
        expandableRowsComponent={EditSchool}
        defaultSortAsc={false}
        pagination
        highlightOnHover
        noHeader
      />
    </div>
  );
};

AdminSchoolsPage.auth = {
  role: ["super"],
};
AdminSchoolsPage.layout = AdminLayout;
AdminSchoolsPage.title = "Churches";
AdminSchoolsPage.cta = {
  title: "Add Church",
  url: "/admin/churches/new",
};
export default AdminSchoolsPage;
