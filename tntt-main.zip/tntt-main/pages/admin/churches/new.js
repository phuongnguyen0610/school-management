import AdminLayout from "layouts/admin";
import { useState } from "react";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchPostJSON } from "@lib/healper";
import { useRouter } from "next/router";

const AdminNewSchoolPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [name, setName] = useState("");
  const [location, setLocation] = useState("");
  const router = useRouter();

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPostJSON("/api/schools", {
      name,
      location,
    });
    if (response.statusCode === 201) {
      toast.success(response.message, { duration: 4000 });
      router.push("/admin/churches");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };
  return (
    <div className="w-full lg:my-8 ">
      <img
        src="/img/svg/new.svg"
        className="fixed right-0 bottom-0 max-w-lg z-0 hidden md:block"
      />
      <div className="px-8 max-w-lg py-16 mx-auto md:mx-0 border-gray-200 sm:shadow-card rounded-2xl z-10 bg-white relative">
        <form onSubmit={onSubmit}>
          <div className="flex flex-col space-y-6">
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Name of Church
              </p>
              <input
                onChange={(event) => {
                  setName(event.target.value);
                }}
                value={name}
                required
                type="text"
                name="school-name"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Location</p>
              <input
                onChange={(event) => {
                  setLocation(event.target.value);
                }}
                value={location}
                required
                type="text"
                name="location"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <button
              disabled={isLoading}
              type="submit"
              className="inline-flex items-center justify-center w-full px-10 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
            >
              {isLoading ? (
                <span className="inline-flex text-2xl animate-spin text-white">
                  <CgSpinner />
                </span>
              ) : (
                "Submit"
              )}
            </button>
          </div>
          {errorMessage ? (
            <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
              {errorMessage}
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
};

AdminNewSchoolPage.auth = {
  role: ["super"],
};
AdminNewSchoolPage.layout = AdminLayout;
AdminNewSchoolPage.title = "Add New Church";
export default AdminNewSchoolPage;
