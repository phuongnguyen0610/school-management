import AdminLayout from "layouts/admin";
import { useState } from "react";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchPostJSON } from "@lib/healper";
import { useRouter } from "next/router";

const AdminNewUserPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const router = useRouter();

  const onSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPostJSON("/api/users", {
      firstName,
      lastName,
      email,
      password,
      role,
    });
    if (response.statusCode === 201) {
      toast.success(response.message, { duration: 4000 });
      router.push("/admin");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };
  return (
    <div className="w-full lg:my-8 ">
      <img
        src="/img/svg/new.svg"
        className="fixed right-0 bottom-0 max-w-lg z-0 hidden md:block"
      />
      <div className="px-8 max-w-lg py-16 mx-auto md:mx-0 border-gray-200 sm:shadow-card rounded-2xl z-10 bg-white relative">
        <form onSubmit={onSubmit}>
          <div className="flex flex-col space-y-6">
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">First Name</p>
              <input
                onChange={(event) => {
                  setFirstName(event.target.value);
                }}
                value={firstName}
                required
                type="text"
                name="fname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Last Name</p>
              <input
                onChange={(event) => {
                  setLastName(event.target.value);
                }}
                value={lastName}
                required
                type="text"
                name="lname"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Email Address
              </p>

              <input
                onChange={(event) => {
                  setEmail(event.target.value);
                }}
                value={email}
                name="email"
                required
                type="email"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>

            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Role</p>
              <select
                className="block invalid:text-gray-500 rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                required
                name="role"
                onChange={(event) => {
                  setRole(event.target.value);
                }}
              >
                <option disabled value="" selected>
                  ...
                </option>
                <option value="admin">Admin</option>
                <option value="parent">Parent</option>
                <option value="super">Super</option>
                {/* <option value="teacher">Teacher</option> */}
              </select>
            </div>

            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Password</p>
              <input
                onChange={(event) => {
                  setPassword(event.target.value);
                }}
                value={password}
                required
                type="password"
                name="password"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <button
              disabled={isLoading}
              type="submit"
              className="inline-flex items-center justify-center w-full px-10 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
            >
              {isLoading ? (
                <span className="inline-flex text-2xl animate-spin text-white">
                  <CgSpinner />
                </span>
              ) : (
                "Submit"
              )}
            </button>
          </div>
          {errorMessage ? (
            <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
              {errorMessage}
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
};

AdminNewUserPage.auth = {
  role: ["super"],
};
AdminNewUserPage.layout = AdminLayout;
AdminNewUserPage.title = "Add New User";
export default AdminNewUserPage;
