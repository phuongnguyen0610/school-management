import AdminLayout from "layouts/admin";
import { useState, useEffect } from "react";
import { CgSpinner } from "react-icons/cg";
import toast from "react-hot-toast";
import { fetchGetJSON, fetchPostJSON } from "@lib/healper";
import { useRouter } from "next/router";
import SelectSearch, { fuzzySearch } from "react-select-search-nextjs";
import { useSession, signOut } from "next-auth/client";

const AdminNewPaymentPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [session, loading] = useSession();
  const user = !!session?.user;
  const [errorMessage, setErrorMessage] = useState(null);
  const [date, setDate] = useState("");
  const [method, setMethod] = useState("");
  const [checkId, setCheckId] = useState("");
  const [amount, setAmount] = useState("");
  const [familyId, setFamilyId] = useState("");
  const [receivedBy, setReceivedBy] = useState("");
  const [families, setFamilies] = useState([]);
  const router = useRouter();

  const onSubmit = async (event) => {
    event.preventDefault();
    if (!familyId) {
      toast.error("Please provide all the information!");
      return;
    }
    setIsLoading(true);
    setErrorMessage(null);
    const response = await fetchPostJSON("/api/payments", {
      date,
      method,
      checkId,
      amount,
      familyId,
      receivedBy,
    });
    if (response.statusCode === 201) {
      toast.success(response.message, { duration: 4000 });
      router.push("/admin/payments");
      setIsLoading(false);
      return;
    } else {
      toast.error(response.message);
      setIsLoading(false);
      return;
    }
  };
  useEffect(() => {
    const unsubs = async () => {
      const response = await fetchGetJSON("/api/family");
      if (response.statusCode === 200) {
        setFamilies(response?.families);
      }
      setIsLoading(false);
    };
    return unsubs();
  }, []);

  useEffect(() => {
    const unsubs = async () => {
      if (user) {
        setReceivedBy(
          `${session?.user?.name?.firstName} ${session?.user?.name?.lastName}`
        );
      }
      setIsLoading(false);
    };
    return unsubs();
  }, [loading]);

  const options = families.map((family) => ({
    name: `ID : ${family.familyId} - Father :  ${family.fatherFirstName} ${family.fatherLastName}`,
    value: family.familyId,
  }));
  return (
    <div className="w-full lg:my-8 ">
      <img
        src="/img/svg/new.svg"
        className="fixed right-0 bottom-0 max-w-lg z-0 hidden md:block"
      />
      <div className="px-8 max-w-lg py-16 mx-auto md:mx-0 border-gray-200 sm:shadow-card rounded-2xl z-10 bg-white relative">
        <form onSubmit={onSubmit}>
          <div className="flex flex-col space-y-6">
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Date</p>
              <input
                onChange={(event) => {
                  setDate(event.target.value);
                }}
                value={date}
                required
                type="date"
                name="date"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Payment Method
              </p>
              <select
                className="block invalid:text-gray-500 rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                required
                name="method"
                onChange={(event) => {
                  setMethod(event.target.value);
                }}
              >
                <option disabled value="" selected>
                  ...
                </option>
                <option value="cash">Cash</option>
                <option value="check">Check</option>
              </select>
            </div>
            {method == "check" && (
              <div className="flex flex-col space-y-1">
                <p className="font-semibold text-sm text-gray-600">Check ID</p>
                <input
                  onChange={(event) => {
                    setCheckId(event.target.value);
                  }}
                  value={checkId}
                  required
                  type="text"
                  name="check-id"
                  className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
                />
              </div>
            )}
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Amount</p>
              <input
                onChange={(event) => {
                  setAmount(event.target.value);
                }}
                value={amount}
                required
                type="number"
                name="amount"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">Received By</p>
              <input
                onChange={(event) => {
                  setReceivedBy(event.target.value);
                }}
                readOnly
                value={receivedBy}
                required
                type="text"
                name="receved-by"
                className="block rounded w-full border bg-white dark:bg-black border-gray-200 dark:border-gray-700 text-sm"
              />
            </div>
            <div className="flex flex-col space-y-1">
              <p className="font-semibold text-sm text-gray-600">
                Paid By (Family ID)
              </p>
              <SelectSearch
                onChange={setFamilyId}
                options={options}
                name="family-id"
                search
                filterOptions={fuzzySearch}
                emptyMessage="Not found"
                placeholder="Choose..."
              />
            </div>
            <button
              disabled={isLoading}
              type="submit"
              className="inline-flex items-center justify-center w-full px-10 py-2 font-semibold text-white transition duration-500 ease-in-out transform bg-primary rounded hover:bg-pink-300 focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2 "
            >
              {isLoading ? (
                <span className="inline-flex text-2xl animate-spin text-white">
                  <CgSpinner />
                </span>
              ) : (
                "Submit"
              )}
            </button>
          </div>
          {errorMessage ? (
            <div className=" text-red-500 py-2 text-sm font-medium w-full text-center">
              {errorMessage}
            </div>
          ) : null}
        </form>
      </div>
    </div>
  );
};

AdminNewPaymentPage.auth = {
  role: ["super", "admin"],
};
AdminNewPaymentPage.layout = AdminLayout;
AdminNewPaymentPage.title = "Add New Payment";
export default AdminNewPaymentPage;
