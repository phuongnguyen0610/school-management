import Link from "next/link";

const PageNotFound = () => {
  return (
    <div className="w-full h-screen fixed inset-0 flex justify-center items-center">
      <div className="max-w-lg mx-auto">
        <div className="text-center flex flex-col space-y-2">
          <img
            className="mb-8 mx-auto max-w-xs sm:max-w-md"
            src="/img/svg/404.svg"
          />
          <p className="text-3xl text-gray-700 font-bold font-serif">
            Page Not Found
          </p>
          <div className="font-medium text-pink-700 text-opacity-30">
            Sorry, we cant find the page you are looking for <br /> You can go
            back to{" "}
            <Link href="/">
              <a className="font-bold text-pink-700 duration-300 hover:text-primary">
                home page
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PageNotFound;
