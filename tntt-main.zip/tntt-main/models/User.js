import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const userSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, required: true, default: "parent" },
  },
  {
    timestamps: true,
  }
);

if (!mongoose.models.User) {
  userSchema.plugin(AutoIncrement, { inc_field: "userId" });
}
const User = mongoose.models.User || mongoose.model("User", userSchema);
export default User;