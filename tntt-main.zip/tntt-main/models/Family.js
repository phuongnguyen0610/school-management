import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const familySchema = new mongoose.Schema(
  {
    parentId: { type: String, required: true, unique: true },
    fatherFirstName: { type: String, required: true },
    fatherLastName: { type: String, required: true },
    // fatherPhone: { type: String, required: true },
    fatherPhone: { type: String, required: false},
    fatherEmail: { type: String, required: false},
    motherFirstName: { type: String, required: true },
    motherLastName: { type: String, required: true },
    motherPhone: { type: String, required: false},
    motherEmail: { type: String, required: false},
    address: { type: String, required: false },
    city: { type: String, required: false },
    state: { type: String, required: false },
    zip: { type: String, required: false },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.Family) {
  familySchema.plugin(AutoIncrement, { inc_field: "familyId" });
}
const Family = mongoose.models.Family || mongoose.model("Family", familySchema);
export default Family;
