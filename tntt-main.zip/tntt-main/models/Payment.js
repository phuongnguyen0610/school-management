import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const paymentSchema = new mongoose.Schema(
  {
    date: { type: Date, required: true },
    method: { type: String, required: true },
    checkId: { type: String },
    amount: { type: Number, required: true },
    familyId: { type: String, required: true },
    receivedBy: { type: String },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.Payment) {
  paymentSchema.plugin(AutoIncrement, { inc_field: "paymentId" });
}
const Payment =
  mongoose.models.Payment || mongoose.model("Payment", paymentSchema);
export default Payment;
