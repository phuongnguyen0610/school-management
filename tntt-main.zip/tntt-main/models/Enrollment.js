import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const enrollmentSchema = new mongoose.Schema(
  {
    familyId: { type: String, required: true },
    Date: { type: Date, required: true },
    schoolName: { type: String, required: true },
    fatherPhone: { type: String, required: false},
    fatherEmail: { type: String, required: false},
    motherPhone: { type: String, required: false},
    address: { type: String, required: false },
    city: { type: String, required: false },
    state: { type: String, required: false },
    zip: { type: String, required: false },
    emergencyName: { type: String, required: false},
    emergencyRelationship: { type: String, required: false},
    emergencyPhone: { type: String, required: false},
    total_fee: {type: Decimal128, required: false},
    notes: { type: String },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.Enrollment) {
  enrollmentSchema.plugin(AutoIncrement, { inc_field: "enrollmentId" });
}

const Enrollment =
  mongoose.models.Enrollment || mongoose.model("Enrollment", enrollmentSchema);
export default Enrollment;
