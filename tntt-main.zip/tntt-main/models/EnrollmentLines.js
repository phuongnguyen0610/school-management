import { Decimal128 } from "mongodb";
import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const enrollmentLinesSchema = new mongoose.Schema(
  {
    enrollmentId: { type: String, required: true },
    studentId: { type: String, required: true },
    activity: { type: String, required: true },
    nganh: { type: String, required: true },
    cap: { type: String, required: true },
    fee: { type: Decimal128, required: true },
    enrolled: { type: Boolean, required: true },
    notes: { type: String },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.EnrollmentLines) {
  enrollmentLinesSchema.plugin(AutoIncrement, { inc_field: "enrollmentLinesId" });
}

const EnrollmentLines =
  mongoose.models.EnrollmentLines || mongoose.model("EnrollmentLines", enrollmentLinesSchema);
export default Enrollment;
