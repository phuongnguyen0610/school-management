import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const studentSchema = new mongoose.Schema(
  {
    familyId: { type: String, required: true },
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    DOB: { type: Date, required: true },
    saint: { type: String, required: true },
    age: { type: Number, required: true },
    gender: { type: String, required: true },
    medical: { type: String },
    nganh: { type: String, required: true },
    cap: { type: String, required: true },
    year: { type: String, required: true },
    enrolled: { type: Boolean, required: true },
    schoolName: { type: String, required: true },
    notes: { type: String },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.Student) {
  studentSchema.plugin(AutoIncrement, { inc_field: "studentId" });
}
const Student =
  mongoose.models.Student || mongoose.model("Student", studentSchema);
export default Student;
