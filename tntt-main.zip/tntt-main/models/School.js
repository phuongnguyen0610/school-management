import mongoose from "mongoose";
const AutoIncrement = require("mongoose-sequence")(mongoose);

const schoolSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
    location: { type: String, required: true },
  },
  {
    timestamps: true,
  }
);
if (!mongoose.models.School) {
  schoolSchema.plugin(AutoIncrement, { inc_field: "schoolId" });
}
const School = mongoose.models.School || mongoose.model("School", schoolSchema);
export default School;
