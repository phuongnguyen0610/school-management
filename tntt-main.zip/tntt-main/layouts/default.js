import Footer from "@components/Footer";
import Nav from "@components/Nav";
import React, { Fragment } from "react";

const DefaultLayout = ({ children }) => {
  return (
    <Fragment>
      <Nav />
      {children}
      <Footer />
    </Fragment>
  );
};

export default DefaultLayout;
