import { Fragment } from "react";
import { FaPlus, FaUsers, FaSchool, FaChild } from "react-icons/fa";
import { BiArrowBack } from "react-icons/bi";
import { MdPayment } from "react-icons/md";
import { IoSchool } from "react-icons/io5";
import Link from "next/link";
import ActiveLink from "@components/ActiveLink";
import { RiAdminFill, RiLogoutBoxRLine } from "react-icons/ri";
import { signOut, useSession } from "next-auth/client";
import { useRouter } from "next/router";

const tabs = [
  { icon: <FaUsers />, title: "Users", href: "/admin" },
  { icon: <FaSchool />, title: "Churches", href: "/admin/churches" },
  { icon: <FaChild />, title: "Family", href: "/admin/family" },
  { icon: <IoSchool />, title: "Children", href: "/admin/children" },
  { icon: <MdPayment />, title: "Payments", href: "/admin/payments" },
];
const AdminLayout = ({ children, title, cta }) => {
  const router = useRouter();
  const [session, loading] = useSession();

  if (session?.user?.role != "super") {
    if (tabs.length >= 5) {
      tabs.splice(0, 2);
    }
  }

  return (
    <Fragment>
      <div className="flex mx-auto lg:max-w-screen-2xl h-screen w-full">
        <aside className="lg:w-1/5 w-[66px] items-center lg:items-baseline lg:min-w-[250px] lg:overflow-y-scroll border-r px-2 lg:px-6 py-2 flex flex-col justify-between">
          <div className="w-full">
            <a
              onClick={() => router.back()}
              className="h-12 w-12 cursor-pointer flex justify-center items-center ml-1 mb-4 hover:text-pink-300 text-3xl text-primary duration-300"
            >
              <BiArrowBack />
            </a>
            <div className="">
              {tabs.map((tab) => (
                <ActiveLink
                  key={tab.title}
                  activeClassName="!text-primary"
                  href={tab.href}
                >
                  <a className="focus:outline-none hover:text-blue text-pink-900 flex items-center py-2 px-4 hover:bg-pink-50 rounded-full mr-auto mb-3">
                    <i className="text-2xl lg:mr-4 text-left">{tab.icon}</i>
                    <p className="text-lg whitespace-nowrap font-semibold text-left hidden lg:block">
                      {tab.title}
                    </p>
                  </a>
                </ActiveLink>
              ))}
            </div>
            {cta && (
              <Link href={cta?.url || "/admin"}>
                <a className="flex justify-center items-center text-white bg-primary rounded-full font-semibold focus:outline-none w-12 h-12 lg:h-auto lg:w-full p-3 hover:bg-pink-300">
                  <p className="hidden lg:block capitalize">{cta?.title}</p>
                  <i className="lg:hidden">
                    <FaPlus />
                  </i>
                </a>
              </Link>
            )}
          </div>
          <div className="lg:w-full relative mt-16">
            <button
              onClick={() => signOut({ callbackUrl: "/" })}
              className="focus:outline-none text-pink-600 hover:text-pink-400 duration-300 flex items-center py-2 px-4 rounded-full mr-auto mb-3"
            >
              <i className="text-2xl mr-4 text-left">
                <RiLogoutBoxRLine />
              </i>
              <p className="text-lg font-semibold text-left hidden lg:block">
                Logout
              </p>
            </button>
          </div>
        </aside>
        {/* Main section */}
        <div className="w-full lg:w-1/2 h-full overflow-y-scroll flex-1">
          <div className="px-5 py-3 border-b border-lighter sticky top-0 flex items-center justify-between bg-white z-30">
            <h1 className="text-xl font-bold text-pink-900">
              {title || "Admin"}
            </h1>
            <div className="text-right">
              <div className="flex items-center justify-center">
                <p className="text-sm font-semibold text-pink-900 leading-3 pt-1">
                  {`${session?.user?.name.lastName} (${session?.user?.role})`}{" "}
                  <br />
                  <span className="text-xs font-medium text-pink-900 text-opacity-50">
                    {session?.user?.email}
                  </span>
                </p>
                <RiAdminFill className="inline-block text-2xl text-pink-900 ml-1" />
              </div>
            </div>
          </div>
          <div className="px-5 py-3">{children}</div>
        </div>
      </div>
    </Fragment>
  );
};

export default AdminLayout;
