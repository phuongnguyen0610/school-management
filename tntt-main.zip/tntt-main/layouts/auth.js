import { useRouter } from "next/router";
import { Fragment, useState, useEffect } from "react";
import { getSession } from "next-auth/client";
import toast from "react-hot-toast";
import Nav from "@components/Nav";
import Footer from "@components/Footer";
import LoadingScreen from "@components/LoadingScreen";

const AuthLayout = ({ children }) => {
  const router = useRouter();
  const path = router.query["next"];
  const nextPath = path ? path : "/";
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getSession().then((session) => {
      if (session) {
        toast.success("You are already logged in!", { duration: 4000 });
        router.push(nextPath);
      } else {
        setIsLoading(false);
      }
    });
  }, [router]);
  if (isLoading) return <LoadingScreen />;

  return (
    <Fragment>
      <Nav />
      {children}
      <Footer />
    </Fragment>
  );
};

export default AuthLayout;
