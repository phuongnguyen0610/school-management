import ActiveLink from "@components/ActiveLink";
import Footer from "@components/Footer";
import Nav from "@components/Nav";
import React, { Fragment } from "react";
import { MdPayment } from "react-icons/md";
import { IoSchool } from "react-icons/io5";

const tabs = [
  { icon: <IoSchool />, title: "My Children", href: "/parents" },
  { icon: <MdPayment />, title: "Payments History", href: "/parents/payments" },
];
const ParentLayout = ({ children }) => {
  return (
    <Fragment>
      <Nav />
      <div className="flex w-max mx-auto items-center mt-28">
        {tabs.map((tab) => (
          <ActiveLink
            key={tab.title}
            activeClassName="!text-primary border-b-2 border-primary"
            href={tab.href}
          >
            <a className="focus:outline-none hover:text-blue text-pink-900 flex items-center py-2 px-2 mx-2 hover:text-primary duration-300 mr-auto mb-3">
              <i className="text-2xl lg:mr-4 text-left">{tab.icon}</i>
              <p className="text-lg whitespace-nowrap font-semibold text-left hidden lg:block">
                {tab.title}
              </p>
            </a>
          </ActiveLink>
        ))}
      </div>
      {children}
      <Footer />
    </Fragment>
  );
};

export default ParentLayout;
